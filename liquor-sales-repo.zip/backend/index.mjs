// Liquor Sales Tracker API: one Lambda behind a Function URL (served via CloudFront at /api/*)
// Auth: Cognito ID token (RS256) verified here. Roles come from Cognito groups: owner | auditor | salesman.
// Owner sees sales, loans, cash and invoices and runs the shop. Auditor confirms money received in the bank (only role that can).
import crypto from "node:crypto";
import zlib from "node:zlib";
import { exportAll, payload, runBackup } from "./backup.mjs";
const sha = (x) => crypto.createHash("sha256").update(String(x)).digest();

const OWNER = "owner", SALES = "salesman", AUDITOR = "auditor", COLS = ["shops", "brands", "daily", "cash", "ledger", "staff"], DENS = [500, 200, 100, 50, 20, 10];
const json = (code, obj) => ({ statusCode: code, headers: { "content-type": "application/json", "cache-control": "no-store" }, body: JSON.stringify(obj) });
const httpErr = (status, error) => Object.assign(new Error(error), { status });
const strip = ({ pk, sk, ...x }) => x;
const str = (v, max) => (typeof v === "string" ? v.trim().slice(0, max) : "");
const num = (v, min, max, int = true) => { const n = Number(v); if (!Number.isFinite(n) || n < min || n > max || (int && !Number.isInteger(n))) throw httpErr(400, "Invalid number"); return n; };
const isId = (s) => typeof s === "string" && /^[A-Za-z0-9_-]{1,40}$/.test(s);
const isDate = (s) => typeof s === "string" && /^\d{4}-\d{2}-\d{2}$/.test(s);
const ymd = (d) => d.toISOString().slice(0, 10);
// Salesmen may only enter today and the previous N days (N = SALESMAN_BACK_DAYS, default 2). Dates use the shop's time zone.
// -1 (the default for now) = no limit: salesmen can enter or correct ANY past date. Set 2 later to lock older days.
const BACK = () => { const n = parseInt(process.env.SALESMAN_BACK_DAYS ?? "-1"); return Number.isFinite(n) && n >= -1 ? n : -1; };
const BUSINESS = () => (process.env.BUSINESS_NAME || "My Business").slice(0, 60);   // only the starting name: the owner renames it in the app
const bizName = async (db) => (await db.get("SETTINGS", "business"))?.name || BUSINESS();
const TZ = process.env.APP_TZ || "Asia/Kolkata";
const todayLocal = (now = new Date()) => new Intl.DateTimeFormat("en-CA", { timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit" }).format(now);
const addDays = (d, n) => ymd(new Date(Date.parse(d + "T00:00:00Z") + n * 864e5));
function checkEntryDate(role, date) {
  if (role !== SALES) return;
  if (!isDate(date)) throw httpErr(400, "Bad date");
  const t = todayLocal();
  if (date > t) throw httpErr(400, "Date is in the future");
  if (BACK() >= 0 && date < addDays(t, -BACK())) throw httpErr(403, `Salesmen can enter only today and the last ${BACK()} days. Ask the owner to change older days.`);
}
// Stock invoice papers: photos / PDFs uploaded by staff, viewed by the owner.
const MAX_FILE = 3.5 * 1024 * 1024, MAX_PER_DAY = 30;
const FILE_TYPES = {
  "image/jpeg": ["jpg", (b) => b[0] === 0xff && b[1] === 0xd8],
  "image/png": ["png", (b) => b.subarray(0, 4).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47]))],
  "image/webp": ["webp", (b) => b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP"],
  "application/pdf": ["pdf", (b) => b.subarray(0, 4).toString() === "%PDF"],
};
const pubInv = ({ pk, sk, key, ...x }) => x;
const need = (v, msg) => { if (!v) throw httpErr(400, msg); return v; };

/* ---------- normalizers: whitelist fields and validate ---------- */
const normShop = (b) => ({ id: b.id, name: need(str(b.name, 80), "Shop name required"), address: str(b.address, 200), phone: str(b.phone, 30), license: str(b.license, 50), startDate: isDate(b.startDate) ? b.startDate : "" });
const normBrand = (b) => ({
  id: b.id, shopId: isId(b.shopId) ? b.shopId : "main", serial: num(b.serial ?? 0, 0, 99999),
  name: need(str(b.name, 80), "Brand name required"), cat: str(b.cat, 20) || "Other",
  size: num(b.size ?? 750, 1, 5000), mrp: num(b.mrp ?? 0, 0, 1e6, false), open: num(b.open ?? 0, 0, 1e6), min: num(b.min ?? 5, 0, 1e5),
  pending: !!b.pending, added: isDate(b.added) ? b.added : ymd(new Date()),
});
/* ---------- salesman PINs: set by the owner only; the PIN identifies the person who is working ---------- */
export const hashPin = (pin) => { const salt = crypto.randomBytes(8).toString("hex"); return salt + ":" + crypto.scryptSync(String(pin), salt, 16, { N: 4096 }).toString("hex"); };
const pinMatches = (pin, h) => { const [salt, hex] = String(h).split(":"); try { return crypto.timingSafeEqual(crypto.scryptSync(String(pin), salt, 16, { N: 4096 }), Buffer.from(hex, "hex")); } catch { return false; } };
const STAFF_TOKEN_MS = 12 * 3600e3;
// PIN-only sign-in: the server issues its own signed session (a JWT-shaped token with an HMAC) after the PIN is checked, so no email or password is needed.
const SESSION_MS = 365 * 864e5;
const b64u = (o) => Buffer.from(JSON.stringify(o)).toString("base64url");
const signSession = (c, secret) => { const h = b64u({ alg: "HS256", typ: "LIQ" }), p = b64u(c); return `${h}.${p}.${crypto.createHmac("sha256", secret).update(h + "." + p).digest("base64url")}`; };
const readSession = (tok, secret) => {
  const [h, p, sig] = String(tok).split(".");
  if (!h || !p || !sig) return null;
  try {
    if (JSON.parse(Buffer.from(h, "base64url").toString()).typ !== "LIQ") return null;
    if (!crypto.timingSafeEqual(sha(sig), sha(crypto.createHmac("sha256", secret).update(h + "." + p).digest("base64url")))) return null;
    const c = JSON.parse(Buffer.from(p, "base64url").toString());
    return c.exp * 1000 > Date.now() ? c : null;
  } catch { return null; }
};
const signStaff = (p, secret) => { const b = Buffer.from(JSON.stringify(p)).toString("base64url"); return b + "." + crypto.createHmac("sha256", secret).update(b).digest("base64url"); };
const pubStaff = ({ pk, sk, pinHash, pv, ...x }) => ({ ...x, hasPin: !!pinHash });
const lockShop = (ctx, shopId) => { // a salesman, or a shop login, only ever touches his own shop
  const own = ctx.role === SALES ? ctx.staff.shopId || "main" : ctx.scope;
  if (own && (shopId || "main") !== own) throw httpErr(403, ctx.role === SALES ? "Your PIN is for another shop" : "This shop login is for another shop");
};
const pubShop = ({ pk, sk, mgrPinHash, ...x }) => ({ ...x, hasMgrPin: !!mgrPinHash });
const normStaff = (b) => ({ id: b.id, shopId: isId(b.shopId) ? b.shopId : "main", name: need(str(b.name, 60), "Enter the salesman's name"), active: b.active !== false });
const normDaily = (b) => ({
  id: b.id, date: b.date, shopId: b.shopId, brandId: b.brandId, name: str(b.name, 80), size: num(b.size ?? 750, 1, 5000),
  mrp: num(b.mrp ?? 0, 0, 1e6, false), received: num(b.received ?? 0, 0, 1e6),
  tin: num(b.tin ?? 0, 0, 1e6), out: num(b.out ?? 0, 0, 1e6),   // stock transferred in from / out to another shop: set only by the transfer endpoint
  staff: str(b.staff, 60), by: str(b.by, 60),
  closing: b.closing === null || b.closing === undefined || b.closing === "" ? null : num(b.closing, 0, 1e6),
});

// Day collection: UPI (PhonePe) amount + cash by denomination. Cash total is always recomputed here.
const bank = (v) => (v ? { amount: num(v.amount, 0, 1e8, false), date: isDate(v.date) ? v.date : ymd(new Date()), clearedDate: isDate(v.clearedDate) ? v.clearedDate : null } : null);
const normCash = (b, owner, ex) => {
  const manual = b.mode === "manual";   // cash entered as one total instead of counted by notes: the total is kept in "coins", notes stay 0, so every sum downstream still works
  const den = {}; let cash = 0;
  for (const d of DENS) { const n = manual ? 0 : num(b.den?.[d] ?? 0, 0, 1e6); den[d] = n; cash += d * n; }
  const coins = num(b.coins ?? 0, 0, 1e8, false);
  return {
    id: b.id, date: b.date, shopId: b.shopId, upi: num(b.upi ?? 0, 0, 1e8, false), den, coins, cash: cash + coins, mode: manual ? "manual" : "notes",
    // Bank marks are set only through the bankOnly path (auditor or owner): normal owner and salesman saves can never set or clear these
    upiBank: owner ? bank(b.upiBank) : ex?.upiBank || null,
    cashBank: owner ? bank(b.cashBank) : ex?.cashBank || null,
  };
};

// Ledger: expenses and loans (credit given). The owner later marks a loan as received by cash or UPI.
const normLedger = (b, owner) => {
  const type = b.type === "loan" ? "loan" : b.type === "expense" ? "expense" : (() => { throw httpErr(400, "Type must be expense or loan"); })();
  const received = owner && b.status === "received";
  return {
    id: b.id, shopId: b.shopId, date: isDate(b.date) ? b.date : (() => { throw httpErr(400, "Bad date"); })(), type,
    amount: num(b.amount, 0.01, 1e8, false), note: str(b.note, 100),
    status: received ? "received" : "open",
    recvMode: received && ["cash", "upi"].includes(b.recvMode) ? b.recvMode : null,
    recvDate: received && isDate(b.recvDate) ? b.recvDate : null,
    // "till" = collected at the counter and counted in that day's cash/UPI; "direct" = paid straight to the owner
    recvIn: received ? (b.recvIn === "till" ? "till" : "direct") : null,
    old: !!b.old, // paid back before it was ever recorded here: NOT a loan given on that date
  };
};

/* ---------- core write (shared by PUT /items and POST /batch) ---------- */
// Edit history: who changed what, and when. Salesmen may now correct any past date, so every change to an existing figure
// (and every back-dated first entry) is recorded where the owner and auditor can see it.
const audit = (ctx, rec) => ctx.db.put({ pk: "AUDIT", sk: new Date().toISOString() + "#" + crypto.randomBytes(3).toString("hex"), by: ctx.email, role: ctx.role, ...rec });
async function putItem(ctx, col, id, body) {
  const { db, role } = ctx;
  if (!COLS.includes(col)) throw httpErr(404, "Unknown collection");
  if (!body || typeof body !== "object") throw httpErr(400, "Bad body");
  if (body.id !== undefined && body.id !== id) throw httpErr(400, "id mismatch");
  if (ctx.scope && col === "shops") throw httpErr(403, "Only the admin can change shops");
  if (role === AUDITOR && col !== "cash" && col !== "daily") throw httpErr(403, "The auditor can only correct closing stock and confirm money received in the bank");
  if (col === "staff") { // the salesman roster is kept by the owner or the auditor
    if (role === SALES || role === AUDITOR) throw httpErr(403, "Only the owner can add or change salesmen");
    if (!isId(id)) throw httpErr(400, "Bad id");
    const name = need(str(body.name, 60), "Enter the salesman's name");
    const shopId = isId(body.shopId) ? body.shopId : "main";
    const dup = (await db.query("STAFF")).find((x) => x.id !== id && (x.shopId || "main") === shopId && x.name.toLowerCase() === name.toLowerCase());
    if (dup) throw httpErr(409, "That salesman is already in this shop's list");
    lockShop(ctx, shopId);
    const ex = await db.get("STAFF", id), item = normStaff({ ...body, id, name, shopId });
    if (ex) lockShop(ctx, ex.shopId || "main");
    let pinHash = ex?.pinHash, pv = ex?.pv || 0, pinSet = false;
    if (body.pin !== undefined && body.pin !== "" && body.pin !== null) {
      if (role !== OWNER) throw httpErr(403, "Only the owner can set a salesman's PIN");
      const pin = String(body.pin);
      if (!/^\d{4,8}$/.test(pin)) throw httpErr(400, "The PIN must be 4 to 8 digits");
      if (await ctx.isReserved(pin)) throw httpErr(409, "That PIN is reserved. Choose a different one for the salesman.");
      if ((await db.query("STAFF")).some((x) => x.id !== id && x.pinHash && pinMatches(pin, x.pinHash))) throw httpErr(409, "That PIN is already used by another salesman. Choose a different one.");
      pinHash = hashPin(pin); pv += 1; pinSet = true;
    }
    await db.put({ pk: "STAFF", sk: id, ...item, ...(pinHash ? { pinHash, pv } : {}) });
    if (pinSet) await audit(ctx, { col: "staff", shopId, text: `PIN ${ex?.pinHash ? "changed" : "set"} for ${item.name}` });
    if (!ex) await audit(ctx, { col: "staff", shopId, text: `Added salesman ${item.name}` });
    else if (ex.active !== item.active) await audit(ctx, { col: "staff", shopId, text: `${item.name} marked ${item.active ? "active" : "not working here"}` });
    else if (ex.name !== item.name) await audit(ctx, { col: "staff", shopId, text: `Salesman renamed ${ex.name} → ${item.name}` });
    return pubStaff({ ...item, pinHash });
  }
  if (col === "shops") {
    if (role !== OWNER) throw httpErr(403, "Only the owner can change shops");
    if (!isId(id)) throw httpErr(400, "Bad id");
    const item = normShop({ ...body, id });
    const exs = await db.get("SHOPS", id);
    let mgrPinHash = exs?.mgrPinHash;
    if (body.mgrPin !== undefined && body.mgrPin !== null && body.mgrPin !== "") { // the admin gives each shop its own login PIN
      const pin = String(body.mgrPin);
      if (!/^\d{6,8}$/.test(pin)) throw httpErr(400, "The shop PIN must be 6 to 8 digits");
      if (await ctx.isReserved(pin)) throw httpErr(409, "That PIN is reserved. Choose a different one.");
      if ((await db.query("STAFF")).some((x) => x.pinHash && pinMatches(pin, x.pinHash)) || (await db.query("SHOPS")).some((x) => x.id !== id && x.mgrPinHash && pinMatches(pin, x.mgrPinHash))) throw httpErr(409, "Someone already uses that PIN. Choose a different one.");
      mgrPinHash = hashPin(pin);
      await audit(ctx, { col: "pin", shopId: id, text: `Shop login PIN ${exs?.mgrPinHash ? "changed" : "set"} for ${item.name}` });
    }
    if (body.mgrPin === null) { mgrPinHash = undefined; await audit(ctx, { col: "pin", shopId: id, text: `Shop login switched off for ${item.name}` }); }
    await db.put({ pk: "SHOPS", sk: id, ...item, ...(mgrPinHash ? { mgrPinHash } : {}) });
    return pubShop({ ...item, mgrPinHash });
  }
  if (col === "brands") {
    if (!isId(id)) throw httpErr(400, "Bad id");
    let item;
    if (role === OWNER) {
      if (ctx.scope) { lockShop(ctx, body.shopId); const ob = await db.get("BRANDS", id); if (ob) lockShop(ctx, ob.shopId || "main"); }
      item = normBrand({ ...body, id });
    }
    else {
      if (await db.get("BRANDS", id)) throw httpErr(403, "Only the owner can edit brands");
      lockShop(ctx, body.shopId);
      item = normBrand({ ...body, id, open: 0, pending: true }); // salesman: may set the MRP when adding a new brand; opening stock stays 0 and the owner reviews it (pending)
    }
    await db.put({ pk: "BRANDS", sk: id, ...item });
    return item;
  }
  if (col === "cash") { // id = YYYY-MM-DD_shopId; salesman and owner may both write it
    const m = /^(\d{4}-\d{2}-\d{2})_([A-Za-z0-9_-]{1,40})$/.exec(id);
    if (!m) throw httpErr(400, "Bad cash id");
    checkEntryDate(role, m[1]);
    lockShop(ctx, m[2]);
    const ex = await db.get("CASH#" + m[2], m[1]);
    if (role === AUDITOR || (role === OWNER && body.bankOnly === true)) { // the auditor (or the owner, with bankOnly) can only mark / undo the bank receipt of a day that already has a collection
      if (!ex) throw httpErr(404, "No collection entered for that day");
      const item = { ...strip(ex), upiBank: body.upiBank !== undefined ? bank(body.upiBank) : ex.upiBank || null, cashBank: body.cashBank !== undefined ? bank(body.cashBank) : ex.cashBank || null };
      await db.put({ pk: "CASH#" + m[2], sk: m[1], ...item });
      const was = (b) => (b ? b.amount + (b.clearedDate ? " (shortfall settled)" : "") : "not received");
      if (JSON.stringify(ex.upiBank || null) !== JSON.stringify(item.upiBank)) await audit(ctx, { col: "bank", date: m[1], shopId: m[2], text: `UPI to bank: ${was(ex.upiBank)} → ${was(item.upiBank)}` });
      if (JSON.stringify(ex.cashBank || null) !== JSON.stringify(item.cashBank)) await audit(ctx, { col: "bank", date: m[1], shopId: m[2], text: `Cash deposit: ${was(ex.cashBank)} → ${was(item.cashBank)}` });
      return item;
    }
    if (role === SALES && (ex?.upiBank || ex?.cashBank)) throw httpErr(403, "This day is already reconciled with the bank. Ask the owner to change it.");
    const item = normCash({ ...body, id, date: m[1], shopId: m[2] }, false, ex);
    await db.put({ pk: "CASH#" + m[2], sk: m[1], ...item });
    if (ex && (ex.upi !== item.upi || ex.cash !== item.cash)) await audit(ctx, { col: "collection", date: m[1], shopId: m[2], text: `Collection changed: UPI ${ex.upi} → ${item.upi}, cash ${ex.cash} → ${item.cash}` });
    return item;
  }
  if (col === "ledger") {
    if (!isId(id)) throw httpErr(400, "Bad id");
    const shopId = isId(body.shopId) ? body.shopId : "main";
    lockShop(ctx, shopId);
    const key = { pk: "LEDGER#" + shopId, sk: id };
    if (role !== OWNER) {
      const ex = await db.get(key.pk, key.sk);
      if (ex) { // the only thing a salesman may do to an existing entry: mark an OPEN loan as received at the counter
        const same = ex.type === "loan" && ex.status !== "received" && ex.shopId === shopId && ex.date === body.date && body.type === "loan" && Number(ex.amount) === Number(body.amount) && (ex.note || "") === str(body.note, 100);
        if (!same) throw httpErr(403, "Only the owner can change ledger entries");
        if (body.status !== "received" || !["cash", "upi"].includes(body.recvMode) || !isDate(body.recvDate)) throw httpErr(400, "Choose cash or UPI and a valid date");
        checkEntryDate(role, body.recvDate);
        const item = { ...strip(ex), status: "received", recvMode: body.recvMode, recvDate: body.recvDate, recvIn: "till" };
        await db.put({ ...key, ...item });
        return item;
      }
      checkEntryDate(role, body.date);
      if (body.status === "received") { // a customer paid an old loan that was never recorded: log it as received at the counter
        if (body.type !== "loan" || !["cash", "upi"].includes(body.recvMode) || !isDate(body.date)) throw httpErr(400, "Choose cash or UPI");
        const item = { id, shopId, date: body.date, type: "loan", amount: num(body.amount, 0.01, 1e8, false), note: str(body.note, 100), status: "received", recvMode: body.recvMode, recvDate: body.date, recvIn: "till", old: true };
        await db.put({ ...key, ...item });
        return item;
      }
    }
    const item = normLedger({ ...body, id, shopId }, role === OWNER);
    await db.put({ ...key, ...item });
    return item;
  }
  // daily: id = YYYY-MM-DD_brandId
  const m = /^(\d{4}-\d{2}-\d{2})_([A-Za-z0-9]{1,40})$/.exec(id);
  if (!m) throw httpErr(400, "Bad daily id");
  const shopId = isId(body.shopId) ? body.shopId : "main";
  checkEntryDate(role, m[1]);
  lockShop(ctx, shopId);
  if (role === SALES) { // nothing can be entered on or before the day the owner fixed the starting stock
    const sh = await db.get("SHOPS", shopId);
    if (sh?.startDate && m[1] <= sh.startDate) throw httpErr(403, `Stock entry starts the day after ${sh.startDate}. Earlier days are the owner's opening stock.`);
  }
  if (role === AUDITOR) { // the auditor may correct the closing stock of a day the salesman already entered, nothing else
    const k = { pk: "DAILY#" + shopId, sk: m[1] + "#" + m[2] }, ex = await db.get(k.pk, k.sk);
    if (!ex) throw httpErr(404, "No stock entry for that day. The salesman or owner has to enter it first.");
    if (body.closing === null || body.closing === undefined || body.closing === "") throw httpErr(400, "Enter the closing stock");
    const item = { ...strip(ex), closing: num(body.closing, 0, 1e6) };
    await db.put({ ...k, ...item });
    if (ex.closing !== item.closing) await audit(ctx, { col: "stock", date: m[1], shopId, backdated: m[1] < todayLocal(), text: `${item.name} ${item.size}ml: closing ${ex.closing ?? "—"} → ${item.closing} (corrected by the auditor)` });
    return item;
  }
  let staffName = str(body.staff, 60);
  if (role === SALES) { // who worked is chosen from this shop's own active salesmen; the PIN holder is recorded separately as the one who typed it in
    if (!staffName) staffName = ctx.staff.name;
    else if (staffName !== ctx.staff.name && !(await db.query("STAFF")).some((x) => (x.shopId || "main") === shopId && x.active !== false && x.name === staffName)) throw httpErr(400, "Choose the salesman from this shop's list");
  }   // a salesman's entries are always stamped with the name behind his PIN
  const key = { pk: "DAILY#" + shopId, sk: m[1] + "#" + m[2] };
  let mrp = body.mrp;
  if (role !== OWNER) { // salesman cannot set prices: keep the saved MRP, or take the brand's MRP for a new row
    const ex = await db.get(key.pk, key.sk);
    const br = ex ? null : await db.get("BRANDS", m[2]);
    mrp = ex ? ex.mrp : br ? br.mrp : 0;
  }
  const before = await db.get(key.pk, key.sk);
  const item = normDaily({ ...body, id, date: m[1], shopId, brandId: m[2], mrp, staff: staffName, by: role === SALES ? ctx.staff.name : str(body.by, 60), tin: before?.tin || 0, out: before?.out || 0 });
  await db.put({ ...key, ...item });
  const back = m[1] < todayLocal();
  if ((before && (before.closing !== item.closing || before.received !== item.received)) || (!before && back)) {
    await audit(ctx, { col: "stock", date: m[1], shopId, backdated: back, text: `${item.staff ? "[" + item.staff + "] " : ""}${item.name} ${item.size}ml: closing ${before?.closing ?? "—"} → ${item.closing ?? "—"}, received ${before?.received ?? 0} → ${item.received}` });
  }
  return item;
}


// Stock transfer between two shops of the same business: it leaves the sending shop as "out" (not a sale) and arrives in the other shop as stock received ("tin").
const bumpDaily = async (db, shopId, date, brand, field, delta, by) => {
  const key = { pk: "DAILY#" + shopId, sk: date + "#" + brand.id }, ex = await db.get(key.pk, key.sk);
  const row = ex ? strip(ex) : { id: date + "_" + brand.id, date, shopId, brandId: brand.id, name: brand.name, size: brand.size, mrp: brand.mrp || 0, received: 0, staff: "", by: by || "", closing: null, tin: 0, out: 0 };
  row[field] = Math.max(0, (row[field] || 0) + delta);
  await db.put({ ...key, ...row });
  return row;
};
async function transfer(ctx, body) {
  const { db, role } = ctx;
  if (role !== OWNER && role !== SALES) throw httpErr(403, "Only the owner or a salesman can transfer stock");
  const date = body.date, from = isId(body.fromShop) ? body.fromShop : "main", to = isId(body.toShop) ? body.toShop : "";
  if (!isDate(date)) throw httpErr(400, "Bad date");
  if (date > todayLocal()) throw httpErr(400, "Date is in the future");
  checkEntryDate(role, date); lockShop(ctx, from);
  if (!to || to === from) throw httpErr(400, "Choose the other shop");
  const qty = Math.round(Number(body.qty));
  if (!(qty >= 1 && qty <= 1e5)) throw httpErr(400, "Enter how many bottles");
  const shops = await db.query("SHOPS"), known = (id) => id === "main" || shops.some((x) => x.id === id);
  if (!known(from) || !known(to)) throw httpErr(404, "Shop not found");
  for (const sid of [from, to]) { const sh = shops.find((x) => x.id === sid); if (role === SALES && sh?.startDate && sid === from && date <= sh.startDate) throw httpErr(403, `Stock entry starts the day after ${sh.startDate}`); }
  const src = await db.get("BRANDS", String(body.brandId || ""));
  if (!src || (src.shopId || "main") !== from) throw httpErr(404, "Brand not found in the sending shop");
  const brands = await db.query("BRANDS");
  let dst = brands.find((b) => (b.shopId || "main") === to && b.name.trim().toLowerCase() === src.name.trim().toLowerCase() && +b.size === +src.size), created = null;
  if (!dst) { // the receiving shop does not stock this brand yet: add it (same MRP, flagged for the owner to check and set its opening stock)
    const serial = Math.max(0, ...brands.filter((b) => (b.shopId || "main") === to).map((b) => b.serial || 0)) + 1;
    dst = { id: "t" + crypto.randomBytes(5).toString("hex"), shopId: to, serial, name: src.name, cat: src.cat, size: src.size, mrp: src.mrp || 0, open: 0, min: src.min || 5, pending: true, added: date };
    await db.put({ pk: "BRANDS", sk: dst.id, ...dst }); created = dst;
  }
  const id = crypto.randomBytes(5).toString("hex"), nm = (sid) => shops.find((x) => x.id === sid)?.name || sid;
  const by = role === SALES ? ctx.staff.name : "";
  const t = { id, date, fromShop: from, toShop: to, fromBrandId: src.id, toBrandId: dst.id, name: src.name, size: src.size, qty, note: str(body.note, 120), by: by || ctx.email, at: new Date().toISOString() };
  await db.put({ pk: "XFER", sk: date + "#" + id, ...t });
  const a = await bumpDaily(db, from, date, src, "out", qty, by), b = await bumpDaily(db, to, date, dst, "tin", qty, by);
  await audit(ctx, { col: "stock", date, shopId: from, text: `Stock transfer: ${qty} × ${src.name} ${src.size}ml ${nm(from)} → ${nm(to)}${t.note ? " (" + t.note + ")" : ""}` });
  return { transfer: t, rows: [a, b], ...(created ? { brand: created } : {}) };
}
async function undoTransfer(ctx, date, id) {
  const { db, role } = ctx;
  if (role !== OWNER && role !== SALES) throw httpErr(403, "Only the owner or a salesman can undo a transfer");
  const t = isDate(date) && isId(id) ? await db.get("XFER", date + "#" + id) : null;
  if (!t) throw httpErr(404, "Transfer not found");
  checkEntryDate(role, t.date); lockShop(ctx, t.fromShop);
  const brandOf = async (bid, sid) => (await db.get("BRANDS", bid)) || { id: bid, shopId: sid, name: t.name, size: t.size, mrp: 0 };
  const a = await bumpDaily(db, t.fromShop, t.date, await brandOf(t.fromBrandId, t.fromShop), "out", -t.qty), b = await bumpDaily(db, t.toShop, t.date, await brandOf(t.toBrandId, t.toShop), "tin", -t.qty);
  await db.del("XFER", t.date + "#" + t.id);
  await audit(ctx, { col: "stock", date: t.date, shopId: t.fromShop, text: `Stock transfer undone: ${t.qty} × ${t.name} ${t.size}ml` });
  return { rows: [a, b] };
}

async function allData(db, days, onlyShop) {
  const cutoff = ymd(new Date(Date.now() - days * 864e5));
  const [shops, brands, staff] = await Promise.all([db.query("SHOPS"), db.query("BRANDS"), db.query("STAFF")]);
  const ids = new Set(["main", ...shops.map((s) => s.id), ...brands.map((b) => b.shopId || "main")]);
  const lparts = await Promise.all([...ids].map((s) => db.query("LEDGER#" + s)));
  const [parts, cparts] = await Promise.all([Promise.all([...ids].map((s) => db.query("DAILY#" + s, cutoff))), Promise.all([...ids].map((s) => db.query("CASH#" + s, cutoff)))]);
  const xfers = await db.query("XFER", cutoff);
  const all = { transfers: xfers.map(strip), staff: staff.map(pubStaff).sort((a, b) => a.name.localeCompare(b.name)), shops: shops.map(pubShop), brands: brands.map(strip), daily: parts.flat().map(strip), cash: cparts.flat().map(strip), ledger: lparts.flat().map(strip) };
  if (!onlyShop) return all;
  const mine = (x) => (x.shopId || "main") === onlyShop;   // a salesman only ever receives his own shop's figures
  return { transfers: all.transfers.filter((t) => t.fromShop === onlyShop || t.toShop === onlyShop), staff: all.staff.filter(mine), shops: all.shops.filter((x) => x.id === onlyShop), brands: all.brands.filter(mine), daily: all.daily.filter(mine), cash: all.cash.filter(mine), ledger: all.ledger.filter(mine) };
}

/* ---------- handler factory (dependencies injected so it can be unit-tested) ---------- */
const PIN_MAX_TRIES = 5, PIN_LOCK_MS = 15 * 60 * 1000;
// Owner accounts must also present the owner PIN (x-owner-pin header) on every request.
async function checkPin(db, email, given, isRight) {
  const key = ["LOCK#" + email, "pin"];
  const lock = (await db.get(...key)) || { count: 0, until: 0 };
  if (lock.until > Date.now()) throw httpErr(429, "Too many wrong PINs. Try again in a few minutes.");
  if (!given) throw Object.assign(httpErr(403, "PIN required"), { pin: true });
  const ok = await isRight(String(given));
  if (ok) { if (lock.count) await db.put({ pk: key[0], sk: key[1], count: 0, until: 0 }); return; }
  const count = lock.count + 1, locked = count >= PIN_MAX_TRIES;
  await db.put({ pk: key[0], sk: key[1], count: locked ? 0 : count, until: locked ? Date.now() + PIN_LOCK_MS : 0 });
  throw Object.assign(httpErr(403, locked ? "Too many wrong PINs. Locked for 15 minutes." : "Wrong PIN"), { pin: true });
}

function makeTenantHandler({ db, idp, verify, ownerPin, auditorPin = "", store, files, staffSecret = process.env.STAFF_SECRET || "dev-secret" }) {
  // The owner controls every PIN. Once the owner sets one in the app it is stored hashed and the deploy-time value is no longer used.
  const envPin = (role) => (role === OWNER ? ownerPin : auditorPin) || "";
  const adminOk = async (role, given) => {
    const h = (await db.get("SETTINGS", "pins"))?.[role + "Hash"];
    if (h) return pinMatches(String(given), h);
    const e = envPin(role);
    return !!e && crypto.timingSafeEqual(sha(given), sha(e));
  };
  const adminSet = async (role) => !!((await db.get("SETTINGS", "pins"))?.[role + "Hash"] || envPin(role));
  const shopPinUsed = async (pin, exceptId) => (await db.query("SHOPS")).some((x) => x.id !== exceptId && x.mgrPinHash && pinMatches(String(pin), x.mgrPinHash));
  const isReserved = async (pin) => (await adminOk(OWNER, pin)) || (await adminOk(AUDITOR, pin)) || (await shopPinUsed(pin));
  let resetChecked = false;   // "I forgot the PIN": a redeploy with a new PinReset value clears the PINs stored in the app, so the deploy-time PINs work again
  const checkReset = async () => {
    if (resetChecked) return; resetChecked = true;
    const tok = process.env.PIN_RESET || "";
    if (!tok) return;
    const m = await db.get("SETTINGS", "pinreset");
    if (m?.value !== tok) { await db.del("SETTINGS", "pins"); await db.put({ pk: "SETTINGS", sk: "pinreset", value: tok }); }
  };
  return async (event) => {
    try {
      const method = event.requestContext?.http?.method || event.httpMethod;
      const path = (event.rawPath || "/").replace(/^\/api/, "").replace(/\/+$/, "") || "/";
      // Public: only the shop names, so the first screen can show one icon per shop before anyone signs in.
      if (method === "GET" && path === "/public/shops") {
        const sh = await db.query("SHOPS");
        const biz = await bizName(db);
        return json(200, { business: biz, shops: sh.length ? sh.map((x) => ({ id: x.id, name: x.name, mgr: !!x.mgrPinHash })) : [{ id: "main", name: biz, mgr: false }] });
      }
      if (method === "POST" && path === "/auth/pin") { // public: the PIN itself signs the phone in
        let b = {}; try { b = JSON.parse(event.isBase64Encoded ? Buffer.from(event.body || "", "base64").toString() : event.body || "{}"); } catch { throw httpErr(400, "Bad JSON"); }
        const isShop = b.role === "shop";
        const role = isShop ? OWNER : [OWNER, AUDITOR, SALES].includes(b.role) ? b.role : null;
        if (!role) throw httpErr(400, "Choose Admin, Shop, Salesman or Auditor");
        await checkReset();
        let shopRec = null;
        if (isShop) { // a shop login: the admin gave this shop its own PIN; it opens that one shop only
          shopRec = isId(b.shopId) ? await db.get("SHOPS", b.shopId) : null;
          if (!shopRec?.mgrPinHash) throw httpErr(403, "Shop login is not set up for this shop. Ask the admin.");
        } else if (role !== SALES && !(await adminSet(role))) throw httpErr(503, role === OWNER ? "The owner PIN is not configured" : "The owner has not set the auditor PIN yet. Ask the owner to set it in the Shops tab.");
        const key = ["LOCK#pinlogin", isShop ? "shop#" + shopRec.sk : role], lock = (await db.get(...key)) || { count: 0, until: 0 };
        if (lock.until > Date.now()) throw httpErr(429, "Too many wrong PINs. Try again in 15 minutes.");
        const pin = String(b.pin || "").slice(0, 32);
        let hit = null, good;
        if (role === SALES) { hit = (await db.query("STAFF")).find((x) => x.active !== false && x.pinHash && pinMatches(pin, x.pinHash)); good = !!hit; }
        else if (isShop) good = pinMatches(pin, shopRec.mgrPinHash);
        else good = await adminOk(role, pin);
        if (!good) {
          const count = lock.count + 1, locked = count >= PIN_MAX_TRIES;
          await db.put({ pk: key[0], sk: key[1], count: locked ? 0 : count, until: locked ? Date.now() + PIN_LOCK_MS : 0 });
          throw Object.assign(httpErr(403, locked ? "Too many wrong PINs. Locked for 15 minutes." : role === SALES ? "Wrong PIN, or the admin has not set one for you yet" : "Wrong PIN"), { pin: true });
        }
        if (hit && isId(b.shopId) && (hit.shopId || "main") !== b.shopId) throw httpErr(403, "This PIN belongs to a different shop. Go back and choose your own shop.");
        if (lock.count) await db.put({ pk: key[0], sk: key[1], count: 0, until: 0 });
        const now = Math.floor(Date.now() / 1000), email = hit ? `${hit.name} (${hit.shopId || "main"})` : isShop ? `${shopRec.name} (shop login)` : `${role}@pin`;
        const out = { role: isShop ? "shop" : role, token: signSession({ email, "cognito:groups": [role], ...(isShop ? { shop: shopRec.sk } : {}), iat: now, exp: now + SESSION_MS / 1000 }, staffSecret), ...(isShop ? { shop: shopRec.sk } : {}) };
        if (hit) { const sh = hit.shopId || "main"; out.staff = { id: hit.sk || hit.id, name: hit.name, shopId: sh }; out.staffToken = signStaff({ sid: hit.sk || hit.id, pv: hit.pv || 1, email, exp: Date.now() + STAFF_TOKEN_MS }, staffSecret); }
        return json(200, out);
      }
      const auth = event.headers?.authorization || event.headers?.Authorization || "";
      if (!auth.startsWith("Bearer ")) throw httpErr(401, "Missing token");
      let claims;
      try { claims = readSession(auth.slice(7), staffSecret) || await verify(auth.slice(7)); } catch (e) { throw httpErr(401, "Invalid token"); }
      const groups = claims["cognito:groups"] || [];
      const scope = readSession(auth.slice(7), staffSecret) && isId(claims.shop) ? claims.shop : null;   // only a PIN session can carry a shop scope
      let role = groups.includes(OWNER) ? OWNER : groups.includes(AUDITOR) ? AUDITOR : groups.includes(SALES) ? SALES : null;
      // one person who is both owner and auditor (a small business) can act as the auditor on request; never any other switch
      if (role === OWNER && groups.includes(AUDITOR) && String(event.headers?.["x-act-as"] || "").toLowerCase() === "auditor") role = AUDITOR;
      if (!role) throw httpErr(403, "No role assigned. Ask the owner to add you to a group.");
      if (role === OWNER && scope) { // shop login: his PIN is kept on his own shop record
        const sh = await db.get("SHOPS", scope);
        if (!sh?.mgrPinHash) throw Object.assign(httpErr(403, "This shop login is switched off. Ask the admin."), { pin: true });
        await checkPin(db, claims.email, event.headers?.["x-owner-pin"], async (g) => pinMatches(String(g), sh.mgrPinHash));
      } else if (role === OWNER || role === AUDITOR) {
        await checkReset();
        if (!(await adminSet(role))) throw httpErr(503, role === OWNER ? "The owner PIN is not configured" : "The owner has not set the auditor PIN yet");
        await checkPin(db, claims.email, event.headers?.["x-owner-pin"], (g) => adminOk(role, g));
      }
      const me = { email: claims.email, role, backDays: BACK(), ...(scope ? { scope } : {}) };
      const ctx = { db, role, email: claims.email, staff: null, isReserved, scope };
      if (scope && (path === "/business" || path === "/pins" || path.startsWith("/backup") || path.startsWith("/users"))) throw httpErr(403, "Only the admin can do that");
      const unlockCall = method === "POST" && path === "/staff/unlock";
      if (role === SALES && !unlockCall) { // a salesman must also have entered his own PIN: it says who he is and which shop he may enter for
        const tk = String(event.headers?.["x-staff-token"] || ""), [b, sig] = tk.split(".");
        const need_pin = () => Object.assign(httpErr(403, "Enter your PIN"), { pin: true });
        if (!b || !sig || !crypto.timingSafeEqual(sha(sig), sha(crypto.createHmac("sha256", staffSecret).update(b).digest("base64url")))) throw need_pin();
        let p; try { p = JSON.parse(Buffer.from(b, "base64url").toString()); } catch { throw need_pin(); }
        const rec = p.exp > Date.now() && p.email === claims.email ? await db.get("STAFF", p.sid) : null;
        if (!rec || rec.active === false || (rec.pv || 1) !== p.pv) throw need_pin();   // PIN changed, or salesman removed: sign in again
        ctx.staff = { id: rec.sk || rec.id, name: rec.name, shopId: rec.shopId || "main" };
        me.staff = ctx.staff;
      }
      let body = {};
      if (event.body) {
        const raw = event.isBase64Encoded ? Buffer.from(event.body, "base64").toString() : event.body;
        try { body = JSON.parse(raw); } catch { throw httpErr(400, "Bad JSON"); }
      }
      const parts = path.split("/").filter(Boolean);

      if (unlockCall) {
        if (role !== SALES) throw httpErr(403, "Only salesmen use a personal PIN");
        const key = ["LOCK#" + claims.email, "staff"], lock = (await db.get(...key)) || { count: 0, until: 0 };
        if (lock.until > Date.now()) throw httpErr(429, "Too many wrong PINs. Try again in a few minutes.");
        const pin = String(body.pin || ""), hit = (await db.query("STAFF")).find((x) => x.active !== false && x.pinHash && pinMatches(pin, x.pinHash));
        if (!hit) {
          const count = lock.count + 1, locked = count >= PIN_MAX_TRIES;
          await db.put({ pk: key[0], sk: key[1], count: locked ? 0 : count, until: locked ? Date.now() + PIN_LOCK_MS : 0 });
          throw Object.assign(httpErr(403, locked ? "Too many wrong PINs. Locked for 15 minutes." : "Wrong PIN, or the owner has not set one for you yet"), { pin: true });
        }
        if (isId(body.shopId) && (hit.shopId || "main") !== body.shopId) throw Object.assign(httpErr(403, "This PIN belongs to a different shop. Go back and choose your own shop."), { pin: true });
        if (lock.count) await db.put({ pk: key[0], sk: key[1], count: 0, until: 0 });
        const exp = Date.now() + STAFF_TOKEN_MS;
        return json(200, { token: signStaff({ sid: hit.sk || hit.id, pv: hit.pv || 1, email: claims.email, exp }, staffSecret), exp, staff: { id: hit.sk || hit.id, name: hit.name, shopId: hit.shopId || "main" } });
      }
      if (method === "GET" && path === "/me") return json(200, { me });
      if (method === "GET" && path === "/data") {
        const days = Math.min(Math.max(parseInt(event.queryStringParameters?.days) || 180, 1), 800);
        const all = await allData(db, days, role === SALES ? ctx.staff.shopId : scope);
        if (role === SALES) all.peers = (await db.query("SHOPS")).filter((x) => x.id !== ctx.staff.shopId).map((x) => ({ id: x.id, name: x.name }));   // names only, so a salesman can pick the shop he sends stock to
        if (role === AUDITOR) { // the auditor sees prices and the day's collections for the read-only sales summary, but no customer names, salesmen or PINs
          Object.assign(all, { ledger: all.ledger.map((l) => ({ ...l, note: "" })), staff: [] });
        }
        return json(200, { ...all, business: await bizName(db), me });
      }
      if (path === "/pins") { // the owner controls every PIN: his own, the auditor's (and the salesmen's, in 👥 Salesmen)
        if (role !== OWNER) throw httpErr(403, "Only the owner can manage PINs");
        if (method === "GET") return json(200, { ownerSet: await adminSet(OWNER), auditorSet: await adminSet(AUDITOR) });
        if (method === "PUT") {
          const who = body.role === "auditor" ? AUDITOR : body.role === "owner" ? OWNER : null;
          if (!who) throw httpErr(400, "Choose owner or auditor");
          const pin = String(body.pin || "");
          if (!/^\d{6,8}$/.test(pin)) throw httpErr(400, "The PIN must be 6 to 8 digits");
          if (await adminOk(who === OWNER ? AUDITOR : OWNER, pin)) throw httpErr(409, "The owner and the auditor must have different PINs");
          if ((await db.query("STAFF")).some((x) => x.pinHash && pinMatches(pin, x.pinHash)) || (await shopPinUsed(pin))) throw httpErr(409, "Someone already uses that PIN. Choose a different one.");
          const cur = (await db.get("SETTINGS", "pins")) || {};
          await db.put({ pk: "SETTINGS", sk: "pins", ...strip(cur), [who + "Hash"]: hashPin(pin), at: new Date().toISOString() });
          await audit(ctx, { col: "pin", text: `${who === OWNER ? "Owner" : "Auditor"} PIN changed` });
          return json(200, { ok: true });
        }
      }
      if (method === "PUT" && path === "/business") { // the owner can name or rename the business at any time
        if (role !== OWNER) throw httpErr(403, "Only the owner can rename the business");
        const name = str(body.name, 60);
        if (!/^[\p{L}\p{N} &.,'-]{1,60}$/u.test(name)) throw httpErr(400, "Use letters, numbers and spaces only (up to 60 characters)");
        const was = await bizName(db);
        await db.put({ pk: "SETTINGS", sk: "business", name });
        if (was !== name) await audit(ctx, { col: "settings", text: `Business renamed ${was} → ${name}` });
        return json(200, { business: name });
      }
      if (method === "PUT" && parts[0] === "items" && parts.length === 3) {
        const item = await putItem(ctx, parts[1], decodeURIComponent(parts[2]), body);
        return json(200, { item });
      }
      if (method === "POST" && path === "/batch") {
        if (!Array.isArray(body.items) || body.items.length > 100) throw httpErr(400, "items must be an array of up to 100");
        const items = [];
        for (const it of body.items) items.push(await putItem(ctx, body.col, it?.id, it));
        return json(200, { items });
      }
      if (method === "DELETE" && parts[0] === "items" && parts.length === 3) {
        const col = parts[1], id = decodeURIComponent(parts[2]);
        if (role !== OWNER) throw httpErr(403, "Only the owner can delete");
        if (scope && col === "shops") throw httpErr(403, "Only the admin can delete shops");
        if (col === "staff") { const old = await db.get("STAFF", id); if (old) lockShop(ctx, old.shopId || "main"); await db.del("STAFF", id); if (old) await audit(ctx, { col: "staff", shopId: old.shopId || "main", text: `Removed salesman ${old.name}` }); return json(200, { ok: true }); }
        if (col === "ledger") { const sh = isId(event.queryStringParameters?.shop) ? event.queryStringParameters.shop : "main"; lockShop(ctx, sh); const old = await db.get("LEDGER#" + sh, id); await db.del("LEDGER#" + sh, id); if (old) await audit(ctx, { col: "ledger", date: old.date, shopId: sh, text: `Deleted ${old.type} ₹${old.amount} (${old.note || "no note"})` }); return json(200, { ok: true }); }
        if (col !== "shops" && col !== "brands") throw httpErr(400, "Cannot delete this collection");
        if (col === "brands") { const ob = await db.get("BRANDS", id); if (ob) lockShop(ctx, ob.shopId || "main"); }
        await db.del(col === "shops" ? "SHOPS" : "BRANDS", id);
        return json(200, { ok: true });
      }
      if (parts[0] === "invoices") {
        if (role === AUDITOR) throw httpErr(403, "The auditor has no access to invoices");
        if (!files) throw httpErr(501, "Invoice storage is not configured");
        const qs = event.queryStringParameters || {};
        if (method === "POST" && parts.length === 1) {
          const shopId = isId(body.shopId) ? body.shopId : "main", date = body.date;
          lockShop(ctx, shopId);
          if (role === AUDITOR) throw httpErr(403, "Auditors cannot upload invoices");
          checkEntryDate(role, date);
          const type = FILE_TYPES[body.contentType];
          if (!type) throw httpErr(400, "Upload a JPG, PNG, WEBP photo or a PDF");
          const buf = Buffer.from(String(body.data || ""), "base64");
          if (!buf.length) throw httpErr(400, "The file is empty");
          if (buf.length > MAX_FILE) throw httpErr(413, "File is too large (limit 3.5 MB). Take the photo at lower quality or send a smaller PDF.");
          if (!type[1](buf)) throw httpErr(400, "The file does not look like a real " + type[0].toUpperCase());
          const same = (await db.query("INV#" + shopId, date)).filter((i) => i.sk.startsWith(date + "#")).length;
          if (same >= MAX_PER_DAY) throw httpErr(429, "Too many invoices for one day");
          const id = crypto.randomBytes(6).toString("hex"), key = `invoices/${shopId}/${date.slice(0, 7)}/${id}.${type[0]}`;
          const item = {
            id, shopId, date, supplier: str(body.supplier, 80), invoiceNo: str(body.invoiceNo, 40), note: str(body.note, 200),
            amount: body.amount === "" || body.amount == null ? null : num(body.amount, 0, 1e8, false),
            key, contentType: body.contentType, size: buf.length, fileName: str(body.fileName, 80), uploadedBy: claims.email, uploadedAt: new Date().toISOString(),
          };
          await files.put(key, buf, body.contentType);
          await db.put({ pk: "INV#" + shopId, sk: date + "#" + id, ...item });
          return json(200, { invoice: pubInv(item) });
        }
        if (method === "GET" && parts.length === 1) {
          let from = isDate(qs.from) ? qs.from : addDays(todayLocal(), -30), to = isDate(qs.to) ? qs.to : todayLocal();
          if (role === SALES) from = from < addDays(todayLocal(), -7) ? addDays(todayLocal(), -7) : from;   // a salesman sees his own uploads from the last week
          if (to < from || Date.parse(to) - Date.parse(from) > 800 * 864e5) throw httpErr(400, "Bad date range");
          const shops = role === SALES || scope ? [role === SALES ? ctx.staff.shopId || "main" : scope] : (!qs.shop || qs.shop === "all") ? ["main", ...(await db.query("SHOPS")).map((x) => x.id)] : [isId(qs.shop) ? qs.shop : "main"];
          const rows = (await Promise.all([...new Set(shops)].map((sh) => db.query("INV#" + sh, from))))
            .flat().filter((i) => i.sk.slice(0, 10) <= to && (role !== SALES || i.uploadedBy === claims.email));
          return json(200, { invoices: rows.sort((a, b) => (a.sk < b.sk ? 1 : -1)).map(pubInv) });
        }
        // /invoices/{shop}/{date}/{id}[/file]
        if (parts.length >= 4 && isId(parts[1]) && isDate(parts[2]) && /^[a-f0-9]{12}$/.test(parts[3])) {
          lockShop(ctx, parts[1]);
          const pk = "INV#" + parts[1], sk = parts[2] + "#" + parts[3], it = await db.get(pk, sk);
          if (!it) throw httpErr(404, "Invoice not found");
          if (method === "GET" && parts[4] === "file") {
            if (role === SALES && it.uploadedBy !== claims.email) throw httpErr(403, "You can only open invoices you uploaded");
            const buf = await files.get(it.key);
            return { statusCode: 200, isBase64Encoded: true, headers: { "content-type": it.contentType, "content-disposition": `inline; filename="${(it.fileName || "invoice").replace(/[^\w.\- ]/g, "_")}"`, "cache-control": "private, no-store" }, body: Buffer.from(buf).toString("base64") };
          }
          if (method === "DELETE" && parts.length === 4) {
            if (role !== OWNER) throw httpErr(403, "Only the owner can delete invoices");
            await files.del(it.key); await db.del(pk, sk);
            await audit(ctx, { col: "invoice", date: it.date, shopId: parts[1], text: `Deleted invoice ${it.supplier || ""} ${it.invoiceNo || ""} ₹${it.amount ?? "—"}` });
            return json(200, { ok: true });
          }
        }
        throw httpErr(404, "Not found");
      }
      if (method === "POST" && path === "/transfer") return json(200, await transfer(ctx, body));
      if (method === "DELETE" && parts[0] === "transfer" && parts.length === 3) return json(200, await undoTransfer(ctx, decodeURIComponent(parts[1]), decodeURIComponent(parts[2])));
      if (method === "GET" && path === "/audit") {
        if (role !== OWNER) throw httpErr(403, "Only the owner can see the activity log");
        const days = Math.min(Math.max(parseInt(event.queryStringParameters?.days) || 30, 1), 400);
        let rows = await db.query("AUDIT", new Date(Date.now() - days * 864e5).toISOString());
        if (scope) rows = rows.filter((x) => x.shopId === scope);
        return json(200, { audit: rows.sort((a, b) => (a.sk < b.sk ? 1 : -1)).slice(0, 400).map(({ pk, sk, ...x }) => ({ at: sk.slice(0, 24), ...x })) });
      }
      if (parts[0] === "backup") {
        if (role !== OWNER) throw httpErr(403, "Only the owner can manage backups");
        if (!store) throw httpErr(501, "Backups are not configured");
        if (method === "GET" && parts[1] === "status") return json(200, { backups: await store.list(5) });
        if (method === "POST" && parts[1] === "run") return json(200, await runBackup({ db, store }));
        if (method === "GET" && parts[1] === "download") {
          const doc = payload(await exportAll(db)), raw = JSON.stringify(doc);
          if (raw.length < 5e6) return json(200, doc);   // Lambda responses are limited to 6 MB: larger backups travel compressed
          return { statusCode: 200, isBase64Encoded: true, headers: { "content-type": "application/json", "content-encoding": "gzip", "cache-control": "no-store" }, body: zlib.gzipSync(raw).toString("base64") };
        }
      }
      if (parts[0] === "users") {
        if (role !== OWNER) throw httpErr(403, "Only the owner can manage users");
        if (method === "GET") {
          const users = [];
          for (const g of [OWNER, AUDITOR, SALES]) for (const u of await idp.listInGroup(g)) users.push({ email: u.email, role: g, status: u.status, enabled: u.enabled });
          return json(200, { users });
        }
        if (method === "POST") {
          const email = str(body.email, 120).toLowerCase();
          if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw httpErr(400, "Enter a valid email");
          if (![OWNER, AUDITOR, SALES].includes(body.role)) throw httpErr(400, "Role must be owner, auditor or salesman");
          try { await idp.createUser(email); } catch (e) { if (e.name === "UsernameExistsException") throw httpErr(409, "User already exists"); throw e; }
          await idp.addToGroup(email, body.role);
          return json(200, { ok: true });
        }
      }
      throw httpErr(404, "Not found");
    } catch (e) {
      if (e.status) return json(e.status, { error: e.message, ...(e.pin ? { pinRequired: true } : {}) });
      console.error(e);
      return json(500, { error: "Server error" });
    }
  };
}


/* ---------- customers (tenants): the Admin onboards a customer, each customer has its own shops, PINs and data ----------
   A customer is a code such as "kumar". Its rows live under the key prefix "T#kumar#", its invoice files under "t-kumar/",
   its backups under "backups-t/kumar/", and its session tokens are signed with a key derived from the code, so nothing can cross over.
   Requests without an x-tenant header belong to the original (default) customer, so an existing deployment keeps working. */
const CODE_RE = /^[a-z0-9]{3,20}$/, RESERVED_CODES = ["admin", "main", "default", "api", "demo", "public"];
const tenantDb = (db, code) => {
  const P = `T#${code}#`;
  return {
    get: (pk, sk) => db.get(P + pk, sk).then((x) => x && { ...x, pk }),
    put: (it) => db.put({ ...it, pk: P + it.pk }),
    del: (pk, sk) => db.del(P + pk, sk),
    query: (pk, from) => db.query(P + pk, from).then((r) => r.map((x) => ({ ...x, pk }))),
    scan: () => db.scan().then((r) => r.filter((x) => String(x.pk).startsWith(P)).map((x) => ({ ...x, pk: x.pk.slice(P.length) }))),
  };
};
const defaultDb = (db) => ({ ...db, scan: () => db.scan().then((r) => r.filter((x) => !String(x.pk).startsWith("T#") && x.pk !== "TENANT")) });
const pinOf = (v, what) => { const p = String(v ?? "").trim(); if (!/^\d{6,8}$/.test(p)) throw httpErr(400, what + " must be 6 to 8 digits"); return p; };

export function makeHandler(deps) {
  const { db, store, files, staffSecret = process.env.STAFF_SECRET || "dev-secret", adminPin = "" } = deps;
  const cache = new Map();
  const innerFor = (code) => {
    if (!cache.has(code)) {
      cache.set(code, !code ? makeTenantHandler({ ...deps, db: defaultDb(db) }) : makeTenantHandler({
        ...deps, db: tenantDb(db, code), ownerPin: "", auditorPin: "",
        staffSecret: crypto.createHmac("sha256", staffSecret).update("tenant:" + code).digest("hex"),
        files: files && { put: (k, b, ct) => files.put(`t-${code}/${k}`, b, ct), get: (k) => files.get(`t-${code}/${k}`), del: (k) => files.del(`t-${code}/${k}`) },
        store: store && { put: (k, b) => store.put(k.replace(/^backups\//, `backups-t/${code}/`), b), list: (n) => store.list(n, `backups-t/${code}/`) },
      }));
    }
    return cache.get(code);
  };
  const adminSecret = crypto.createHmac("sha256", staffSecret).update("admin").digest("hex");
  const adminRight = (given) => !!adminPin && crypto.timingSafeEqual(sha(given), sha(adminPin));
  const bodyOf = (event) => { try { return JSON.parse(event.isBase64Encoded ? Buffer.from(event.body || "", "base64").toString() : event.body || "{}"); } catch { throw httpErr(400, "Bad JSON"); } };
  const adminApi = async (event, method, path) => {
    const h = Object.fromEntries(Object.entries(event.headers || {}).map(([k, v]) => [k.toLowerCase(), v]));
    if (method === "POST" && path === "/admin/login") {
      const b = bodyOf(event);
      if (!adminPin) throw httpErr(403, "Admin login is not set up on this deployment (AdminPin).");
      await checkPin(db, "admin", b.pin, async (g) => adminRight(g));
      const now = Math.floor(Date.now() / 1000);
      return json(200, { role: "admin", token: signSession({ email: "admin", "cognito:groups": ["admin"], iat: now, exp: now + SESSION_MS / 1000 }, adminSecret) });
    }
    const auth = h.authorization || "";
    const c = auth.startsWith("Bearer ") ? readSession(auth.slice(7), adminSecret) : null;
    if (!c || !(c["cognito:groups"] || []).includes("admin")) throw httpErr(401, "Admin sign-in required");
    await checkPin(db, "admin", h["x-admin-pin"], async (g) => adminRight(g));
    const parts = path.split("/").filter(Boolean);   // admin, tenants, <code>
    if (parts[1] !== "tenants") throw httpErr(404, "Not found");
    if (method === "GET" && !parts[2]) {
      const rows = await db.query("TENANT");
      const out = [];
      { // the original business is managed here too, under the code "main"
        const dd = defaultDb(db), pins = await dd.get("SETTINGS", "pins"), lst = await dd.get("SETTINGS", "listing"), sh = await dd.query("SHOPS");
        out.unshift({ code: "main", name: await bizName(dd), listed: lst?.listed !== false, active: true, createdAt: "0", shops: sh.map((x) => x.name), shopList: sh.length ? sh.map((x) => ({ id: x.id, name: x.name })) : [{ id: "main", name: await bizName(dd) }], ownerSet: !!(pins?.ownerHash || deps.ownerPin), auditorSet: !!(pins?.auditorHash || deps.auditorPin), isMain: true });
      }
      for (const t of rows) {
        const td = tenantDb(db, t.sk), shops = await td.query("SHOPS"), pins = await td.get("SETTINGS", "pins");
        out.push({ code: t.sk, name: t.name, listed: t.listed !== false, active: t.active !== false, createdAt: t.createdAt, shops: shops.map((x) => x.name), shopList: shops.length ? shops.map((x) => ({ id: x.id, name: x.name })) : [{ id: "main", name: await bizName(td) }], ownerSet: !!pins?.ownerHash, auditorSet: !!pins?.auditorHash });
      }
      return json(200, { tenants: [...out.filter((x) => x.isMain), ...out.filter((x) => !x.isMain).sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1))], adminPinSet: true });
    }
    if (method === "PUT" && parts[2] && parts[3] === "shops" && parts[4]) { // the Admin renames a customer's shop, or adds one
      const code = parts[2].toLowerCase(), sid = parts[4], b = bodyOf(event);
      if (code !== "main" && !(await db.get("TENANT", code))) throw httpErr(404, "Customer not found");
      if (!isId(sid)) throw httpErr(400, "Bad id");
      const td = code === "main" ? defaultDb(db) : tenantDb(db, code), name = need(str(b.name, 80), "Shop name required");
      const ex = await td.get("SHOPS", sid);
      if (ex) await td.put({ ...ex, pk: "SHOPS", sk: sid, name });
      else if (sid === "main" && !(await td.query("SHOPS")).length) await td.put({ pk: "SETTINGS", sk: "business", name });   // the single implicit shop carries the business name
      else {
        if (!(await td.query("SHOPS")).length && sid !== "main") await td.put({ pk: "SHOPS", sk: "main", ...normShop({ id: "main", name: await bizName(td) }) });   // keep the implicit first shop (and its stock) when a second one is added
        await td.put({ pk: "SHOPS", sk: sid, ...normShop({ id: sid, name }) });
      }
      cache.delete(code === "main" ? "" : code);
      return json(200, { ok: true, shop: { id: sid, name } });
    }
    if (method === "PUT" && parts[2]) {
      const code = parts[2].toLowerCase(), b = bodyOf(event);
      if (code === "main") { // the original business: PINs, name and login-list visibility are set here, so OWNER_PIN / AUDITOR_PIN in the deploy file are no longer needed
        const dd = defaultDb(db), pins = (await dd.get("SETTINGS", "pins")) || { pk: "SETTINGS", sk: "pins" };
        const oPin = b.ownerPin ? pinOf(b.ownerPin, "Owner PIN") : null, aPin = b.auditorPin ? pinOf(b.auditorPin, "Auditor PIN") : null;
        for (const p of [oPin, aPin]) if (p && adminRight(p)) throw httpErr(400, "That PIN is the Admin PIN. Use a different one");
        if (oPin && aPin && oPin === aPin) throw httpErr(400, "Owner and auditor must have different PINs");
        if (oPin && ((pins.auditorHash && pinMatches(oPin, pins.auditorHash)) || (!pins.auditorHash && !aPin && deps.auditorPin && oPin === deps.auditorPin))) throw httpErr(400, "Owner and auditor must have different PINs");
        if (aPin && ((pins.ownerHash && pinMatches(aPin, pins.ownerHash)) || (!pins.ownerHash && !oPin && deps.ownerPin && aPin === deps.ownerPin))) throw httpErr(400, "Owner and auditor must have different PINs");
        if (oPin || aPin) await dd.put({ ...pins, pk: "SETTINGS", sk: "pins", ...(oPin ? { ownerHash: hashPin(oPin) } : {}), ...(aPin ? { auditorHash: hashPin(aPin) } : {}), at: new Date().toISOString() });
        const nm = str(b.name, 60); if (nm) await dd.put({ pk: "SETTINGS", sk: "business", name: nm });
        if (b.listed !== undefined) await dd.put({ pk: "SETTINGS", sk: "listing", listed: !!b.listed });
        return json(200, { ok: true, tenant: { code: "main", name: nm || (await bizName(dd)), active: true } });
      }
      if (!CODE_RE.test(code) || RESERVED_CODES.includes(code)) throw httpErr(400, "Customer code: 3 to 20 lowercase letters or digits");
      const ex = await db.get("TENANT", code), td = tenantDb(db, code);
      const name = str(b.name, 60) || ex?.name; if (!name) throw httpErr(400, "Enter the customer name");
      const pins = (await td.get("SETTINGS", "pins")) || { pk: "SETTINGS", sk: "pins" };
      const oPin = b.ownerPin ? pinOf(b.ownerPin, "Owner PIN") : null, aPin = b.auditorPin ? pinOf(b.auditorPin, "Auditor PIN") : null;
      if (!ex && !oPin) throw httpErr(400, "Set the customer's owner PIN (6 to 8 digits)");
      if (oPin && adminRight(oPin)) throw httpErr(400, "That PIN is the Admin PIN. Use a different one");
      if (aPin && adminRight(aPin)) throw httpErr(400, "That PIN is the Admin PIN. Use a different one");
      const finalO = oPin ? hashPin(oPin) : pins.ownerHash, finalA = aPin ? hashPin(aPin) : pins.auditorHash;
      if ((oPin || aPin) && finalO && finalA) {
        const o2 = oPin || null, a2 = aPin || null;
        if ((o2 && pinMatches(o2, finalA)) || (a2 && pinMatches(a2, finalO))) throw httpErr(400, "Owner and auditor must have different PINs");
      }
      await td.put({ ...pins, pk: "SETTINGS", sk: "pins", ...(finalO ? { ownerHash: finalO } : {}), ...(finalA ? { auditorHash: finalA } : {}), at: new Date().toISOString() });
      if (name) await td.put({ pk: "SETTINGS", sk: "business", name });
      const rec = { pk: "TENANT", sk: code, name, active: b.active === undefined ? ex?.active !== false : !!b.active, listed: b.listed === undefined ? ex?.listed !== false : !!b.listed, createdAt: ex?.createdAt || new Date().toISOString() };
      await db.put(rec);
      cache.delete(code);
      return json(200, { ok: true, tenant: { code, name: rec.name, active: rec.active } });
    }
    throw httpErr(404, "Not found");
  };
  return async (event) => {
    try {
      const method = event.requestContext?.http?.method || event.httpMethod;
      const path = (event.rawPath || "/").replace(/^\/api/, "").replace(/\/+$/, "") || "/";
      if (path.startsWith("/admin/")) return await adminApi(event, method, path);
      if (method === "GET" && path === "/public/customers") { // the Shop login screen lists the customers (and their shop names) so nobody has to type a code
        const out = [];
        const dd0 = defaultDb(db), pins0 = await dd0.get("SETTINGS", "pins"), lst0 = await dd0.get("SETTINGS", "listing");
        if ((deps.ownerPin || pins0?.ownerHash) && lst0?.listed !== false) { const dd = dd0, sh = await dd.query("SHOPS"); out.push({ code: "", name: await bizName(dd), shops: sh.map((x) => x.name) }); }
        for (const t of (await db.query("TENANT")).sort((a, b) => a.name.localeCompare(b.name))) {
          if (t.active === false || t.listed === false) continue;
          out.push({ code: t.sk, name: t.name, shops: (await tenantDb(db, t.sk).query("SHOPS")).map((x) => x.name) });
        }
        return json(200, { customers: out });
      }
      const code = String(Object.entries(event.headers || {}).find(([k]) => k.toLowerCase() === "x-tenant")?.[1] || "").toLowerCase().trim();
      if (code) {
        const rec = CODE_RE.test(code) ? await db.get("TENANT", code) : null;
        if (!rec) throw httpErr(404, "Customer code not found. Check it with the person who set you up.");
        if (rec.active === false) throw httpErr(403, "This account is switched off. Contact the administrator.");
      }
      return await innerFor(code)(event);
    } catch (e) {
      if (e.status) return json(e.status, { error: e.message, ...(e.pin ? { pinRequired: true } : {}) });
      console.error(e);
      return json(500, { error: "Server error" });
    }
  };
}

/* ---------- production dependencies ---------- */
const REGION = process.env.AWS_REGION, POOL = process.env.USER_POOL_ID, CLIENT = process.env.CLIENT_ID;
let jwks = null;
async function getJwk(kid) {
  if (!jwks || !jwks.some((k) => k.kid === kid)) {
    const r = await fetch(`https://cognito-idp.${REGION}.amazonaws.com/${POOL}/.well-known/jwks.json`);
    jwks = (await r.json()).keys;
  }
  return jwks.find((k) => k.kid === kid);
}
export async function verifyToken(token) {
  const [h, p, s] = token.split(".");
  if (!h || !p || !s) throw new Error("malformed");
  const head = JSON.parse(Buffer.from(h, "base64url").toString());
  if (head.alg !== "RS256") throw new Error("alg");
  const jwk = await getJwk(head.kid);
  if (!jwk) throw new Error("kid");
  const ok = crypto.verify("RSA-SHA256", Buffer.from(h + "." + p), crypto.createPublicKey({ key: jwk, format: "jwk" }), Buffer.from(s, "base64url"));
  if (!ok) throw new Error("signature");
  const c = JSON.parse(Buffer.from(p, "base64url").toString());
  if (c.iss !== `https://cognito-idp.${REGION}.amazonaws.com/${POOL}` || c.token_use !== "id" || c.aud !== CLIENT || c.exp * 1000 < Date.now()) throw new Error("claims");
  return c;
}

export async function makeDb() {
  const { DynamoDBClient } = await import("@aws-sdk/client-dynamodb");
  const { DynamoDBDocumentClient, GetCommand, PutCommand, DeleteCommand, QueryCommand, ScanCommand } = await import("@aws-sdk/lib-dynamodb");
  const c = DynamoDBDocumentClient.from(new DynamoDBClient({}), { marshallOptions: { removeUndefinedValues: true } });
  const TableName = process.env.TABLE;
  return {
    get: async (pk, sk) => (await c.send(new GetCommand({ TableName, Key: { pk, sk } }))).Item,
    put: (Item) => c.send(new PutCommand({ TableName, Item })),
    del: (pk, sk) => c.send(new DeleteCommand({ TableName, Key: { pk, sk } })),
    query: async (pk, skFrom) => {
      const out = []; let ExclusiveStartKey;
      do {
        const r = await c.send(new QueryCommand({
          TableName, ExclusiveStartKey,
          KeyConditionExpression: skFrom ? "pk = :p AND sk >= :s" : "pk = :p",
          ExpressionAttributeValues: skFrom ? { ":p": pk, ":s": skFrom } : { ":p": pk },
        }));
        out.push(...r.Items); ExclusiveStartKey = r.LastEvaluatedKey;
      } while (ExclusiveStartKey);
      return out;
    },
    // full scan in 500-record pages (eventually consistent reads cost half). A whole year of a busy shop is only a few hundred
    // read units, which the table's burst allowance absorbs; if DynamoDB ever throttles, the SDK retries automatically.
    scan: async () => {
      const out = []; let ExclusiveStartKey;
      do {
        const r = await c.send(new ScanCommand({ TableName, ExclusiveStartKey, Limit: 500 }));
        out.push(...r.Items); ExclusiveStartKey = r.LastEvaluatedKey;
      } while (ExclusiveStartKey);
      return out;
    },
  };
}

export async function makeStore() {
  const bucket = process.env.BACKUP_BUCKET;
  if (!bucket) return null;
  const { S3Client, PutObjectCommand, ListObjectsV2Command } = await import("@aws-sdk/client-s3");
  const c = new S3Client({});
  return {
    put: (Key, Body) => c.send(new PutObjectCommand({ Bucket: bucket, Key, Body, ContentType: "application/gzip" })),
    list: async (n, prefix = "backups/") => { // newest first
      const all = []; let ContinuationToken;
      do {
        const r = await c.send(new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, ContinuationToken }));
        all.push(...(r.Contents || [])); ContinuationToken = r.IsTruncated ? r.NextContinuationToken : undefined;
      } while (ContinuationToken);
      return all.sort((a, b) => (a.Key < b.Key ? 1 : -1)).slice(0, n).map((o) => ({ key: o.Key, size: o.Size, lastModified: o.LastModified.toISOString() }));
    },
  };
}

export async function makeFiles() {
  const Bucket = process.env.INVOICE_BUCKET;
  if (!Bucket) return null;
  const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } = await import("@aws-sdk/client-s3");
  const c = new S3Client({});
  return {
    put: (Key, Body, ContentType) => c.send(new PutObjectCommand({ Bucket, Key, Body, ContentType })),
    get: async (Key) => Buffer.from(await (await c.send(new GetObjectCommand({ Bucket, Key }))).Body.transformToByteArray()),
    del: (Key) => c.send(new DeleteObjectCommand({ Bucket, Key })),
  };
}

async function realDeps() {
  const cog = await import("@aws-sdk/client-cognito-identity-provider");
  const ic = new cog.CognitoIdentityProviderClient({});
  const idp = {
    createUser: (email) => ic.send(new cog.AdminCreateUserCommand({ UserPoolId: POOL, Username: email, DesiredDeliveryMediums: ["EMAIL"], UserAttributes: [{ Name: "email", Value: email }, { Name: "email_verified", Value: "true" }] })),
    addToGroup: (email, GroupName) => ic.send(new cog.AdminAddUserToGroupCommand({ UserPoolId: POOL, Username: email, GroupName })),
    listInGroup: async (GroupName) => {
      const r = await ic.send(new cog.ListUsersInGroupCommand({ UserPoolId: POOL, GroupName }));
      return (r.Users || []).map((u) => ({ email: (u.Attributes || []).find((a) => a.Name === "email")?.Value || u.Username, status: u.UserStatus, enabled: u.Enabled }));
    },
  };
  return { db: await makeDb(), store: await makeStore(), files: await makeFiles(), idp, verify: verifyToken, ownerPin: process.env.OWNER_PIN || "", auditorPin: process.env.AUDITOR_PIN || "", adminPin: process.env.ADMIN_PIN || "", staffSecret: process.env.STAFF_SECRET };
}

let cached;
export const handler = async (event) => { cached ??= makeHandler(await realDeps()); return cached(event); };
