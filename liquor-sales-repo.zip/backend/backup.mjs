// Backup helpers shared by the nightly job and the "Back up now" / "Download" buttons.
import zlib from "node:zlib";

// Everything in the table except temporary PIN-lockout counters.
export async function exportAll(db) {
  return (await db.scan()).filter((i) => !String(i.pk).startsWith("LOCK#"));
}
export const payload = (items, now = new Date()) => ({ app: "liquor-tracker", version: 1, createdAt: now.toISOString(), count: items.length, items });
export const backupKey = (d = new Date()) => {
  const iso = d.toISOString();
  return `backups/${iso.slice(0, 10)}/${iso.slice(11, 19).replace(/:/g, "")}.json.gz`;
};
export async function runBackup({ db, store, now = new Date() }) {
  const items = await exportAll(db);
  const body = zlib.gzipSync(JSON.stringify(payload(items, now)));
  const key = backupKey(now);
  await store.put(key, body);
  return { key, count: items.length, bytes: body.length, createdAt: now.toISOString() };
}
