// Nightly backup (EventBridge schedule, see template.yaml). Writes a compressed copy of the database to S3.
import { makeDb, makeStore } from "./index.mjs";
import { runBackup } from "./backup.mjs";

export const handler = async () => {
  const r = await runBackup({ db: await makeDb(), store: await makeStore() });
  console.log("backup ok", JSON.stringify(r));
  return r;
};
