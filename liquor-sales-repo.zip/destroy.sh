#!/usr/bin/env bash
# Removes the app so nothing keeps running. Usage: ./destroy.sh [--delete-data]
# Without --delete-data your database and user pool are kept (they are protected). Provisioned
# DynamoDB capacity left behind still counts toward your 25-unit free allowance but costs nothing inside it.
set -euo pipefail
STACK="${STACK:-liquor-tracker}"; REGION="${AWS_REGION:-ap-south-1}"
out() { aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
read -r -p "Delete stack '$STACK' in $REGION? Type yes: " ans; [ "$ans" = "yes" ] || { echo "Cancelled."; exit 1; }
POOL=$(out UserPoolId 2>/dev/null || true); BUCKET=$(out BucketName 2>/dev/null || true); BBUCKET=$(out BackupBucketName 2>/dev/null || true)
TABLE=$(aws cloudformation describe-stack-resource --stack-name "$STACK" --region "$REGION" --logical-resource-id Table --query StackResourceDetail.PhysicalResourceId --output text 2>/dev/null || true)
[ -n "$BUCKET" ] && aws s3 rm "s3://$BUCKET" --recursive --region "$REGION" || true
aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"
aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"
echo "Stack deleted."
if [ "${1:-}" = "--delete-data" ]; then
  [ -n "$TABLE" ] && aws dynamodb delete-table --table-name "$TABLE" --region "$REGION" >/dev/null && echo "Deleted table $TABLE"
  [ -n "$BBUCKET" ] && aws s3 rb "s3://$BBUCKET" --force --region "$REGION" && echo "Deleted backup bucket $BBUCKET"
  [ -n "$POOL" ] && aws cognito-idp delete-user-pool --user-pool-id "$POOL" --region "$REGION" && echo "Deleted user pool $POOL"
else
  echo "Kept: backup bucket '${BBUCKET:-?}', DynamoDB table '${TABLE:-?}' and Cognito pool '${POOL:-?}' (your data). Re-run with --delete-data to remove them too."
fi
