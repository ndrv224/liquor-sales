// Run with: node --test test/backend.test.mjs       (no AWS account or dependencies needed)
import test, { after } from "node:test";
import assert from "node:assert/strict";
import zlib from "node:zlib";
import { makeHandler, hashPin } from "../backend/index.mjs";

const mem = new Map();
const db = {
  get: async (pk, sk) => mem.get(pk + "|" + sk),
  put: async (it) => { mem.set(it.pk + "|" + it.sk, structuredClone(it)); },
  del: async (pk, sk) => { mem.delete(pk + "|" + sk); },
  scan: async () => [...mem.values()].map((i) => structuredClone(i)),
  query: async (pk, from) => [...mem.values()].filter((i) => i.pk === pk && (!from || i.sk >= from)).map((i) => structuredClone(i)),
};
const users = [];
const idp = {
  createUser: async (e) => { if (users.find((u) => u.email === e)) throw Object.assign(new Error("x"), { name: "UsernameExistsException" }); users.push({ email: e, group: null }); },
  addToGroup: async (e, g) => { users.find((u) => u.email === e).group = g; },
  listInGroup: async (g) => users.filter((u) => u.group === g).map((u) => ({ email: u.email, status: "FORCE_CHANGE_PASSWORD", enabled: true })),
};
const verify = async (t) => { if (t === "owner") return { email: "o@x.com", "cognito:groups": ["owner"] }; if (t === "both") return { email: "b@x.com", "cognito:groups": ["owner", "auditor"] }; if (t === "aud") return { email: "a@x.com", "cognito:groups": ["auditor"] }; if (t === "sales") return { email: "s@x.com", "cognito:groups": ["salesman"] }; if (t === "nogroup") return { email: "n@x.com" }; throw new Error("bad"); };
const PIN = "98765", AUDPIN = "246810";
const blobs = new Map();
const store = { put: async (k, b) => { blobs.set(k, { b, t: new Date().toISOString() }); }, list: async (n) => [...blobs.entries()].sort((a, b) => (a[0] < b[0] ? 1 : -1)).slice(0, n).map(([key, v]) => ({ key, size: v.b.length, lastModified: v.t })) };
const fileBlobs = new Map();
const files = { put: async (k, b, ct) => { fileBlobs.set(k, { b, ct }); }, get: async (k) => fileBlobs.get(k).b, del: async (k) => { fileBlobs.delete(k); } };
const h = makeHandler({ db, idp, verify, ownerPin: PIN, auditorPin: AUDPIN, store, files, staffSecret: "testsecret" });
mem.set("STAFF|st0", { pk: "STAFF", sk: "st0", id: "st0", shopId: "main", name: "Ravi", active: true, pinHash: hashPin("1111"), pv: 1 });   // the default salesman (PIN 1111) used by most tests
let STAFFTOK;
{ const r = await h({ requestContext: { http: { method: "POST" } }, rawPath: "/api/staff/unlock", headers: { authorization: "Bearer sales", "x-staff-token": STAFFTOK }, body: JSON.stringify({ pin: "1111" }), queryStringParameters: {} }); STAFFTOK = JSON.parse(r.body).token; }
const call = async (token, method, path, body, pin, query) => {
  const hdr = token ? { authorization: "Bearer " + token } : {};
  if ((token === "owner" || token === "aud") && pin !== null) hdr["x-owner-pin"] = pin ?? (token === "aud" ? AUDPIN : PIN);
  if (token === "sales" && pin !== null) hdr["x-staff-token"] = STAFFTOK;
  const r = await h({ requestContext: { http: { method } }, rawPath: "/api" + path, headers: hdr, body: body ? JSON.stringify(body) : undefined, queryStringParameters: query || {} });
  return { status: r.statusCode, body: JSON.parse(r.body) };
};
const today = new Date().toISOString().slice(0, 10);

test("no/invalid token is rejected", async () => {
  assert.equal((await call(null, "GET", "/data")).status, 401);
  assert.equal((await call("junk", "GET", "/data")).status, 401);
  assert.equal((await call("nogroup", "GET", "/data")).status, 403);
});
test("owner creates shop and brand; salesman cannot change shops", async () => {
  assert.equal((await call("owner", "PUT", "/items/shops/main", { name: "Main Shop", address: "Chennai" })).status, 200);
  assert.equal((await call("owner", "PUT", "/items/brands/b1", { shopId: "main", serial: 1, name: "Royal Stag", size: 750, mrp: 500, open: 20, min: 5 })).status, 200);
  assert.equal((await call("sales", "PUT", "/items/shops/main", { name: "Hacked" })).status, 403);
  assert.equal((await call("sales", "DELETE", "/items/brands/b1")).status, 403);
});
test("salesman new brand: MRP is his own, opening forced to 0, pending for the owner; he cannot edit existing brands", async () => {
  const r = await call("sales", "PUT", "/items/brands/b2", { shopId: "main", name: "Kingfisher", mrp: 999, open: 999 });
  assert.equal(r.status, 200); assert.equal(r.body.item.mrp, 999); assert.equal(r.body.item.open, 0); assert.equal(r.body.item.pending, true);
  assert.equal((await call("sales", "PUT", "/items/brands/b1", { shopId: "main", name: "Royal Stag", mrp: 1 })).status, 403);
});
test("salesman daily entry keeps the brand MRP even if the client sends another", async () => {
  const id = `${today}_b1`;
  const r = await call("sales", "POST", "/batch", { col: "daily", items: [{ id, date: today, shopId: "main", brandId: "b1", name: "Royal Stag", size: 750, mrp: 1, received: 5, closing: 12, staff: "Ravi" }] });
  assert.equal(r.status, 200); assert.equal(r.body.items[0].mrp, 500); assert.equal(r.body.items[0].closing, 12);
  // update again: MRP stays at the saved value
  const r2 = await call("sales", "PUT", `/items/daily/${id}`, { shopId: "main", brandId: "b1", received: 5, closing: 10, mrp: 2, staff: "Ravi" });
  assert.equal(r2.body.item.mrp, 500);
});
test("owner can change MRP on past rows; invalid numbers are rejected", async () => {
  const id = `${today}_b1`;
  assert.equal((await call("owner", "PUT", `/items/daily/${id}`, { shopId: "main", brandId: "b1", received: 5, closing: 10, mrp: 550 })).body.item.mrp, 550);
  assert.equal((await call("owner", "PUT", `/items/daily/${id}`, { shopId: "main", brandId: "b1", received: -3, closing: 10 })).status, 400);
  assert.equal((await call("sales", "PUT", `/items/daily/2999-01-01_b1`, { shopId: "main", brandId: "b1", received: 1, staff: "Ravi" })).status, 400);
});
test("GET /data returns everything for both roles", async () => {
  for (const t of ["owner", "sales"]) {
    const r = await call(t, "GET", "/data");
    assert.equal(r.status, 200); assert.equal(r.body.shops.length, 1); assert.equal(r.body.brands.length, 2); assert.equal(r.body.daily.length, 1);
    assert.ok(!("pk" in r.body.brands[0]));
  }
});
test("only the owner manages users", async () => {
  assert.equal((await call("sales", "GET", "/users")).status, 403);
  assert.equal((await call("owner", "POST", "/users", { email: "new@x.com", role: "salesman" })).status, 200);
  assert.equal((await call("owner", "POST", "/users", { email: "new@x.com", role: "salesman" })).status, 409);
  assert.equal((await call("owner", "POST", "/users", { email: "bad", role: "salesman" })).status, 400);
  assert.equal((await call("owner", "GET", "/users")).body.users[0].email, "new@x.com");
});

test("collection: cash total is recomputed on the server; both roles can save", async () => {
  const id = `${today}_main`;
  const r = await call("sales", "PUT", `/items/cash/${id}`, { upi: 1200.5, den: { 500: 2, 200: 1, 100: 3, 50: 0, 20: 4, 10: 5 }, coins: 35, cash: 999999 });
  assert.equal(r.status, 200); assert.equal(r.body.item.cash, 1000 + 200 + 300 + 80 + 50 + 35); assert.equal(r.body.item.upi, 1200.5);
  assert.equal((await call("owner", "PUT", `/items/cash/${id}`, { upi: 0, den: { 500: 1 } })).body.item.cash, 500);
  assert.equal((await call("sales", "PUT", `/items/cash/${id}`, { upi: -5 })).status, 400);
  assert.equal((await call("sales", "PUT", `/items/cash/2999-01-01_main`, { upi: 5 })).status, 400);
  const d = await call("owner", "GET", "/data"); assert.equal(d.body.cash.length, 1);
});

test("cash can be entered as one total instead of counting notes; the total is what every sum uses; switching back works", async () => {
  const id = `${today}_main`;
  const m = await call("owner", "PUT", `/items/cash/${id}`, { upi: 100, mode: "manual", coins: 54321, den: { 500: 9 } });
  assert.equal(m.status, 200); assert.equal(m.body.item.mode, "manual"); assert.equal(m.body.item.cash, 54321); assert.equal(m.body.item.den[500], 0);   // notes are ignored in total mode
  assert.equal(m.body.item.upi, 100);
  assert.equal((await call("owner", "PUT", `/items/cash/${id}`, { upi: 0, mode: "manual", coins: -5 })).status, 400);
  const n = await call("owner", "PUT", `/items/cash/${id}`, { upi: 0, den: { 500: 2 }, coins: 10 });
  assert.equal(n.body.item.mode, "notes"); assert.equal(n.body.item.cash, 1010);
});
test("owner PIN: required, wrong PIN rejected, lockout after 5 tries; salesman needs no PIN", async () => {
  const noPin = await call("owner", "GET", "/data", undefined, null);
  assert.equal(noPin.status, 403); assert.equal(noPin.body.pinRequired, true);
  for (let i = 0; i < 4; i++) { const w = await call("owner", "GET", "/data", undefined, "00000"); assert.equal(w.status, 403); assert.equal(w.body.error, "Wrong PIN"); }
  const fifth = await call("owner", "GET", "/data", undefined, "00000"); assert.equal(fifth.status, 403); assert.match(fifth.body.error, /Locked/);
  assert.equal((await call("owner", "GET", "/data")).status, 429);            // even the right PIN is refused while locked
  mem.set("LOCK#o@x.com|pin", { pk: "LOCK#o@x.com", sk: "pin", count: 0, until: 0 }); // simulate the 15 minutes passing
  assert.equal((await call("owner", "GET", "/data")).status, 200);
  const noTok = await call("sales", "GET", "/data", undefined, null); assert.equal(noTok.status, 403); assert.equal(noTok.body.pinRequired, true);   // a salesman needs his personal PIN (see the salesman PIN test)
});
test("ledger: salesman adds expense/loan; only owner can mark a loan received by cash or UPI", async () => {
  const id = `${today}_ab12`;
  const add = await call("sales", "PUT", `/items/ledger/${id}`, { shopId: "main", date: today, type: "loan", amount: 750, note: "Ravi", status: "open", recvMode: "cash", recvDate: today });
  assert.equal(add.status, 200); assert.equal(add.body.item.status, "open"); assert.equal(add.body.item.recvMode, null);   // an open loan carries no payment info
  assert.equal((await call("sales", "PUT", `/items/ledger/${id}`, { shopId: "main", date: today, type: "loan", amount: 1, note: "x" })).status, 403);
  assert.equal((await call("sales", "PUT", `/items/ledger/${today}_cd34`, { shopId: "main", date: today, type: "gift", amount: 5 })).status, 400);
  const mark = await call("owner", "PUT", `/items/ledger/${id}`, { shopId: "main", date: today, type: "loan", amount: 750, note: "Ravi", status: "received", recvMode: "upi", recvDate: today });
  assert.equal(mark.body.item.status, "received"); assert.equal(mark.body.item.recvMode, "upi");
  assert.equal((await call("sales", "DELETE", `/items/ledger/${id}`)).status, 403);
  const data = await call("owner", "GET", "/data"); assert.equal(data.body.ledger.length, 1);
  assert.equal((await call("owner", "DELETE", `/items/ledger/${id}`, undefined, undefined, { shop: "main" })).status, 200);
  assert.equal((await call("owner", "GET", "/data")).body.ledger.length, 0);
});

test("bank: auditor marks UPI/cash received next day; salesman cannot set it or edit a reconciled day", async () => {
  const id = `${today}_main`;
  await call("owner", "PUT", `/items/cash/${id}`, { upi: 2000, den: { 500: 4 } });
  const sneaky = await call("sales", "PUT", `/items/cash/${id}`, { upi: 2000, den: { 500: 4 }, upiBank: { amount: 2000, date: today } });
  assert.equal(sneaky.body.item.upiBank, null);                                            // salesman cannot mark it
  const mark = await call("aud", "PUT", `/items/cash/${id}`, { upi: 2000, den: { 500: 4 }, upiBank: { amount: 1990, date: today }, cashBank: { amount: 2000, date: today } });
  assert.equal(mark.body.item.upiBank.amount, 1990); assert.equal(mark.body.item.cashBank.amount, 2000);
  assert.equal((await call("sales", "PUT", `/items/cash/${id}`, { upi: 1, den: {} })).status, 403);   // reconciled: locked for salesman
  const again = await call("aud", "PUT", `/items/cash/${id}`, { upi: 2000, den: { 500: 4 }, upiBank: null, cashBank: null });
  assert.equal(again.body.item.upiBank, null);                                              // auditor can undo
  assert.equal((await call("sales", "PUT", `/items/cash/${id}`, { upi: 2100, den: { 500: 4 } })).status, 200);
});

test("cash shortfall: owner can record a partial deposit and later clear it; salesman cannot clear it", async () => {
  const id = `${today}_main`;
  await call("owner", "PUT", `/items/cash/${id}`, { upi: 0, den: { 500: 4 } });                        // cash counted 2000
  const part = await call("aud", "PUT", `/items/cash/${id}`, { upi: 0, den: { 500: 4 }, cashBank: { amount: 1500, date: today } });
  assert.equal(part.body.item.cashBank.amount, 1500); assert.equal(part.body.item.cashBank.clearedDate, null);
  const sneaky = await call("sales", "PUT", `/items/cash/${id}`, { upi: 0, den: { 500: 4 } });
  assert.equal(sneaky.status, 403);                                                                    // reconciled day is locked for salesman
  const cleared = await call("aud", "PUT", `/items/cash/${id}`, { upi: 0, den: { 500: 4 }, cashBank: { amount: 1500, date: today, clearedDate: today } });
  assert.equal(cleared.body.item.cashBank.clearedDate, today);
});

test("loan received at the counter: salesman may mark an open loan received (cash/UPI) but not change anything else", async () => {
  const id = `${today}_ln99`;
  await call("owner", "PUT", `/items/ledger/${id}`, { shopId: "main", date: today, type: "loan", amount: 400, note: "Meena", status: "open" });
  const base = { shopId: "main", date: today, type: "loan", amount: 400, note: "Meena" };
  assert.equal((await call("sales", "PUT", `/items/ledger/${id}`, { ...base, amount: 1, status: "received", recvMode: "cash", recvDate: today })).status, 403);   // cannot change amount
  assert.equal((await call("sales", "PUT", `/items/ledger/${id}`, { ...base, status: "received", recvMode: "bitcoin", recvDate: today })).status, 400);      // bad mode
  const ok = await call("sales", "PUT", `/items/ledger/${id}`, { ...base, status: "received", recvMode: "upi", recvDate: today, recvIn: "direct" });
  assert.equal(ok.status, 200); assert.equal(ok.body.item.status, "received"); assert.equal(ok.body.item.recvMode, "upi"); assert.equal(ok.body.item.recvIn, "till");
  assert.equal((await call("sales", "PUT", `/items/ledger/${id}`, { ...base, status: "open" })).status, 403);                                                  // cannot undo
  const own = await call("owner", "PUT", `/items/ledger/${id}`, { ...base, status: "received", recvMode: "cash", recvDate: today });
  assert.equal(own.body.item.recvIn, "direct");                                                                                                                // owner's own mark is "direct" unless sent as till
});

test("a salesman can log an unrecorded old loan as received at the counter, but not as anything else", async () => {
  const id = `${today}_old1`;
  const r = await call("sales", "PUT", `/items/ledger/${id}`, { shopId: "main", date: today, type: "loan", amount: 250, note: "Ramu", status: "received", recvMode: "cash", recvDate: "1999-01-01", recvIn: "direct" });
  assert.equal(r.status, 200); assert.equal(r.body.item.status, "received"); assert.equal(r.body.item.recvIn, "till"); assert.equal(r.body.item.recvDate, today); assert.equal(r.body.item.old, true);
  assert.equal((await call("sales", "PUT", `/items/ledger/${today}_old2`, { shopId: "main", date: today, type: "expense", amount: 5, status: "received", recvMode: "cash" })).status, 400);
  assert.equal((await call("sales", "PUT", `/items/ledger/${today}_old3`, { shopId: "main", date: today, type: "loan", amount: 5, status: "received", recvMode: "gold" })).status, 400);
});

test("backups: owner can run, list and download; contents are complete and exclude PIN lock counters; salesman is refused", async () => {
  assert.equal((await call("sales", "GET", "/backup/status")).status, 403);
  assert.equal((await call("sales", "POST", "/backup/run")).status, 403);
  const run = await call("owner", "POST", "/backup/run");
  assert.equal(run.status, 200); assert.ok(run.body.count > 5); assert.match(run.body.key, /^backups\/\d{4}-\d{2}-\d{2}\/\d{6}\.json\.gz$/);
  const file = JSON.parse(zlib.gunzipSync(blobs.get(run.body.key).b).toString());
  assert.equal(file.app, "liquor-tracker"); assert.equal(file.count, file.items.length);
  assert.ok(file.items.some((i) => i.pk === "BRANDS") && file.items.some((i) => String(i.pk).startsWith("DAILY#")) && file.items.some((i) => String(i.pk).startsWith("CASH#")));
  assert.ok(!file.items.some((i) => String(i.pk).startsWith("LOCK#")));
  const st = await call("owner", "GET", "/backup/status"); assert.equal(st.body.backups[0].key, run.body.key);
  const dl = await call("owner", "GET", "/backup/download"); assert.equal(dl.status, 200); assert.equal(dl.body.count, file.count);
});

test("salesman can enter only today and the previous 2 days when the limit is switched on; owner is not limited", async () => {
  process.env.SALESMAN_BACK_DAYS = "2";
  try {
  const day = (n) => new Date(Date.now() + n * 864e5 - (new Date().getTimezoneOffset() === 0 ? 0 : 0)).toISOString().slice(0, 10);
  const loc = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());       // the server's idea of today
  const back = (n) => new Date(Date.parse(loc + "T00:00:00Z") - n * 864e5).toISOString().slice(0, 10);
  const put = (who, d) => call(who, "PUT", `/items/daily/${d}_b1`, { shopId: "main", brandId: "b1", received: 0, closing: 5, staff: "Ravi" });
  assert.equal((await put("sales", back(0))).status, 200);
  assert.equal((await put("sales", back(2))).status, 200);                    // 2 days back: allowed
  const old = await put("sales", back(3));
  assert.equal(old.status, 403); assert.match(old.body.error, /last 2 days/);   // 3 days back: refused
  assert.equal((await put("owner", back(30))).status, 200);                   // owner may edit any day
  const cash = (d) => call("sales", "PUT", `/items/cash/${d}_main`, { upi: 1, den: {} });
  assert.equal((await cash(back(2))).status, 200); assert.equal((await cash(back(3))).status, 403);
  const led = (d, n) => call("sales", "PUT", `/items/ledger/${d}_x${n}`, { shopId: "main", date: d, type: "expense", amount: 5, note: "t" });
  assert.equal((await led(back(1), 1)).status, 200); assert.equal((await led(back(5), 2)).status, 403);
  const batch = await call("sales", "POST", "/batch", { col: "daily", items: [{ id: `${back(1)}_b1`, shopId: "main", brandId: "b1", closing: 1, staff: "Ravi" }, { id: `${back(9)}_b1`, shopId: "main", brandId: "b1", closing: 1, staff: "Ravi" }] });
  assert.equal(batch.status, 403);                                             // one old row in a batch refuses the request
  assert.equal((await call("sales", "GET", "/data")).body.me.backDays, 2);
  } finally { delete process.env.SALESMAN_BACK_DAYS; }
});

test("by default a salesman can correct any past date but never a future one", async () => {
  const loc = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
  const back = (n) => new Date(Date.parse(loc + "T00:00:00Z") - n * 864e5).toISOString().slice(0, 10);
  const put = (d) => call("sales", "PUT", `/items/daily/${d}_b1`, { shopId: "main", brandId: "b1", received: 0, closing: 7, staff: "Ravi" });
  assert.equal((await put(back(40))).status, 200);
  assert.equal((await put(back(-1))).status, 400);
  assert.equal((await call("sales", "GET", "/data")).body.me.backDays, -1);
});

test("invoice papers: salesman uploads, owner views and deletes; bad files and old dates are refused", async () => {
  process.env.SALESMAN_BACK_DAYS = "2";   // switch the date limit on for this test
  after(() => { delete process.env.SALESMAN_BACK_DAYS; });
  const png = Buffer.concat([Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]), Buffer.alloc(200, 7)]);
  const body = (o = {}) => ({ shopId: "main", date: today, supplier: "Shree Traders", invoiceNo: "INV-204", amount: 18450.5, note: "Stag + MH Q", fileName: "bill.png", contentType: "image/png", data: png.toString("base64"), ...o });
  const up = await call("sales", "POST", "/invoices", body());
  assert.equal(up.status, 200); assert.equal(up.body.invoice.supplier, "Shree Traders"); assert.equal(up.body.invoice.uploadedBy, "s@x.com"); assert.ok(!("key" in up.body.invoice));
  assert.equal(fileBlobs.size, 1);
  assert.equal((await call("sales", "POST", "/invoices", body({ contentType: "image/gif" }))).status, 400);                        // type not allowed
  assert.equal((await call("sales", "POST", "/invoices", body({ contentType: "application/pdf" }))).status, 400);                  // PNG bytes labelled as PDF
  assert.equal((await call("sales", "POST", "/invoices", body({ data: Buffer.alloc(4 * 1024 * 1024, 1).toString("base64"), contentType: "application/pdf" }))).status, 413);
  const oldDay = new Date(Date.now() - 20 * 864e5).toISOString().slice(0, 10);
  assert.equal((await call("sales", "POST", "/invoices", body({ date: oldDay }))).status, 403);                                    // salesman 2-day limit applies
  assert.equal((await call("owner", "POST", "/invoices", body({ date: oldDay, supplier: "Old bill" }))).status, 200);              // owner has no limit
  const ownerList = await call("owner", "GET", "/invoices", undefined, undefined, { shop: "all", from: new Date(Date.now() - 40 * 864e5).toISOString().slice(0, 10), to: new Date(Date.now() + 864e5).toISOString().slice(0, 10) });
  assert.equal(ownerList.body.invoices.length, 2);
  const salesList = await call("sales", "GET", "/invoices", undefined, undefined, { shop: "main" });
  assert.equal(salesList.body.invoices.length, 1);                                                                                 // only his own, last 7 days
  const inv = up.body.invoice;
  const file = await h({ requestContext: { http: { method: "GET" } }, rawPath: `/api/invoices/main/${inv.date}/${inv.id}/file`, headers: { authorization: "Bearer owner", "x-owner-pin": PIN }, queryStringParameters: {} });
  assert.equal(file.statusCode, 200); assert.equal(file.isBase64Encoded, true); assert.equal(file.headers["content-type"], "image/png"); assert.ok(Buffer.from(file.body, "base64").equals(png));
  const own = await h({ requestContext: { http: { method: "GET" } }, rawPath: `/api/invoices/main/${inv.date}/${inv.id}/file`, headers: { authorization: "Bearer sales", "x-staff-token": STAFFTOK }, queryStringParameters: {} });
  assert.equal(own.statusCode, 200);                                                                                               // salesman can open his own upload
  const otherId = ownerList.body.invoices.find((i) => i.supplier === "Old bill");
  const notMine = await h({ requestContext: { http: { method: "GET" } }, rawPath: `/api/invoices/main/${otherId.date}/${otherId.id}/file`, headers: { authorization: "Bearer sales", "x-staff-token": STAFFTOK }, queryStringParameters: {} });
  assert.equal(notMine.statusCode, 403);
  assert.equal((await call("sales", "DELETE", `/invoices/main/${inv.date}/${inv.id}`)).status, 403);
  assert.equal((await call("owner", "DELETE", `/invoices/main/${inv.date}/${inv.id}`)).status, 200);
  assert.equal(fileBlobs.size, 1);                                                                                                 // file removed from storage too
});

test("auditor: confirms bank receipts only; owner cannot; auditor cannot change anything else", async () => {
  const id = `${today}_main`;
  await call("sales", "PUT", `/items/cash/${id}`, { upi: 700, den: { 100: 3 } });
  const own = await call("owner", "PUT", `/items/cash/${id}`, { upi: 700, den: { 100: 3 }, upiBank: { amount: 700, date: today } });
  assert.equal(own.body.item.upiBank, null);                                                           // the owner cannot mark the bank
  const aud = await call("aud", "PUT", `/items/cash/${id}`, { upiBank: { amount: 700, date: today }, cashBank: { amount: 300, date: today } });
  assert.equal(aud.status, 200); assert.equal(aud.body.item.upi, 700); assert.equal(aud.body.item.cash, 300);   // counted amounts untouched
  assert.equal(aud.body.item.cashBank.amount, 300);
  assert.equal((await call("aud", "PUT", `/items/cash/2000-01-01_main`, { upiBank: { amount: 1, date: today } })).status, 404);   // no collection that day
  assert.equal((await call("aud", "PUT", `/items/brands/zz`, { name: "x" })).status, 403);
  assert.equal((await call("aud", "POST", "/invoices", { shopId: "main", date: today })).status, 403);
  assert.equal((await call("aud", "PUT", "/items/ledger/zz", { shopId: "main", date: today, type: "expense", amount: 5 })).status, 403);
  assert.equal((await call("aud", "PUT", "/items/staff/zz", { name: "x", shopId: "main" })).status, 403);
  assert.equal((await call("aud", "GET", "/users")).status, 403);
  assert.equal((await call("aud", "GET", "/backup/status")).status, 403);
  const data = await call("aud", "GET", "/data"); assert.equal(data.status, 200); assert.equal(data.body.me.role, "auditor");
  assert.equal((await call("aud", "GET", "/invoices", undefined, undefined, { shop: "all" })).status, 403);   // no invoices for the auditor
  assert.equal((await call("aud", "GET", "/audit")).status, 403);                                              // nor the activity log
  assert.ok(data.body.brands.some((b) => b.mrp > 0));                                                           // prices are visible for the read-only sales summary
  assert.ok(data.body.ledger.every((l) => l.note === "")); assert.deepEqual(data.body.staff, []);              // but no customer names and no salesmen
  const mk = await call("owner", "POST", "/users", { email: "audit@x.com", role: "auditor" }); assert.equal(mk.status, 200);
});

test("auditor has his own PIN: the owner PIN does not work for him", async () => {
  const noPin = await call("aud", "GET", "/data", undefined, "");
  assert.equal(noPin.status, 403); assert.equal(noPin.body.pinRequired, true);
  assert.equal((await call("aud", "GET", "/data", undefined, "00000")).status, 403);
  assert.equal((await call("aud", "GET", "/data", undefined, PIN)).status, 403);        // the owner PIN is not the auditor's
  assert.equal((await call("aud", "GET", "/data")).status, 200);
  assert.equal((await call("owner", "GET", "/data", undefined, AUDPIN)).status, 403);   // and the auditor PIN is not the owner's
  assert.equal((await call("owner", "PUT", "/items/staff/sx", { name: "Z", shopId: "main", pin: PIN })).status, 409);     // salesman PINs cannot reuse them
  assert.equal((await call("owner", "PUT", "/items/staff/sx", { name: "Z", shopId: "main", pin: AUDPIN })).status, 409);
});

test("auditor corrects only the closing stock of a day that already has an entry", async () => {
  await call("sales", "PUT", `/items/daily/${today}_b1`, { shopId: "main", brandId: "b1", received: 4, closing: 9, staff: "Ravi" });
  const r = await call("aud", "PUT", `/items/daily/${today}_b1`, { shopId: "main", brandId: "b1", closing: 7, received: 99, mrp: 1, staff: "Hacker" });
  assert.equal(r.status, 200); const it = r.body.item || r.body;
  assert.equal(it.closing, 7); assert.equal(it.received, 4); assert.equal(it.staff, "Ravi"); assert.notEqual(it.mrp, 1);   // only the closing changed
  assert.equal((await call("aud", "PUT", `/items/daily/2001-01-01_b1`, { shopId: "main", brandId: "b1", closing: 3 })).status, 404);   // cannot create a day
  assert.equal((await call("aud", "PUT", `/items/daily/${today}_b1`, { shopId: "main", brandId: "b1" })).status, 400);
  const log = await call("owner", "GET", "/audit"); assert.ok(log.body.audit.some((x) => /corrected by the auditor/.test(x.text) && x.role === "auditor"));
});

test("activity log: edits to existing figures and back-dated entries are recorded; salesman cannot read it", async () => {
  const loc = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
  const old = new Date(Date.parse(loc + "T00:00:00Z") - 9 * 864e5).toISOString().slice(0, 10);
  const row = (d, c) => call("sales", "PUT", `/items/daily/${d}_b1`, { shopId: "main", brandId: "b1", name: "MH Q", size: 750, received: 0, closing: c, staff: "Ravi" });
  await row(old, 10);                                     // back-dated first entry: logged
  await row(old, 6);                                      // changed existing closing: logged
  await row(old, 6);                                      // unchanged: not logged
  const a = await call("owner", "GET", "/audit"); assert.equal(a.status, 200);
  const mine = a.body.audit.filter((x) => x.date === old);
  assert.equal(mine.length, 2); const chg = mine.find((x) => /closing 10 → 6/.test(x.text)); assert.ok(chg); assert.ok(mine.some((x) => /closing — → 10/.test(x.text))); assert.equal(chg.by, "s@x.com"); assert.equal(chg.backdated, true);
  assert.equal((await call("sales", "GET", "/audit")).status, 403);
  assert.equal((await call("owner", "GET", "/audit")).status, 200);
});

test("salesman PIN: only the owner sets it; the PIN says who is working and for which shop", async () => {
  const raw = async (tok, method, path, body) => { const r = await h({ requestContext: { http: { method } }, rawPath: "/api" + path, headers: { authorization: "Bearer sales", ...(tok ? { "x-staff-token": tok } : {}) }, body: body ? JSON.stringify(body) : undefined, queryStringParameters: {} }); return { status: r.statusCode, body: JSON.parse(r.body) }; };
  const unlock = (pin) => raw(null, "POST", "/staff/unlock", { pin });
  await call("owner", "PUT", "/items/shops/s2", { name: "Second Shop" });
  await call("owner", "PUT", "/items/brands/b2", { shopId: "s2", name: "Stag", size: 750, mrp: 500, open: 5, serial: 1 });
  const add = await call("owner", "PUT", "/items/staff/s9", { name: "Sunil", shopId: "s2", pin: "2222" });
  assert.equal(add.status, 200); assert.equal(add.body.item.hasPin, true); assert.ok(!("pinHash" in add.body.item));       // the hash never leaves the server
  assert.equal((await call("aud", "PUT", "/items/staff/s9", { name: "Sunil", shopId: "s2", pin: "3333" })).status, 403);   // the auditor cannot manage salesmen at all
  const mo = await call("owner", "PUT", "/items/staff/s10", { name: "Mohan", shopId: "s2" }); assert.equal(mo.status, 200); assert.equal(mo.body.item.hasPin, false);   // the owner can add a name
  assert.equal((await call("sales", "PUT", "/items/staff/s9", { name: "Sunil", pin: "9999" })).status, 403);
  assert.equal((await call("owner", "PUT", "/items/staff/s11", { name: "X", shopId: "s2", pin: "2222" })).status, 409);    // the PIN must be unique
  assert.equal((await call("owner", "PUT", "/items/staff/s11", { name: "X", shopId: "s2", pin: "12" })).status, 400);
  assert.equal((await unlock("0000")).status, 403);                                                                       // wrong PIN
  assert.equal((await unlock("")).status, 403);
  const un = await unlock("2222"); assert.equal(un.status, 200); assert.equal(un.body.staff.name, "Sunil"); assert.equal(un.body.staff.shopId, "s2");
  const tok = un.body.token;
  const row = await raw(tok, "PUT", `/items/daily/${today}_b2`, { shopId: "s2", brandId: "b2", received: 0, closing: 1, staff: "Someone Else" });
  assert.equal(row.status, 400);                                                                                           // must be someone on this shop's list
  const row2 = await raw(tok, "PUT", `/items/daily/${today}_b2`, { shopId: "s2", brandId: "b2", received: 0, closing: 1, staff: "Sunil" });
  assert.equal(row2.status, 200); assert.equal(row2.body.item.staff, "Sunil"); assert.equal(row2.body.item.by, "Sunil");
  const other = await raw(tok, "PUT", `/items/daily/${today}_b1`, { shopId: "main", brandId: "b1", received: 0, closing: 1 });
  assert.equal(other.status, 403); assert.match(other.body.error, /another shop/);                                        // locked to his own shop
  assert.equal((await raw(tok, "PUT", `/items/cash/${today}_main`, { upi: 1, den: {} })).status, 403);
  assert.equal((await raw(tok + "x", "GET", "/data")).status, 403);                                                       // forged token
  const d = await raw(tok, "GET", "/data");
  assert.deepEqual(d.body.shops.map((x) => x.id), ["s2"]); assert.ok(d.body.brands.every((b) => b.shopId === "s2")); assert.ok(d.body.daily.every((x) => x.shopId === "s2")); assert.equal(d.body.me.staff.name, "Sunil");
  assert.ok(d.body.staff.every((x) => !("pinHash" in x)));
  assert.equal((await call("owner", "PUT", "/items/staff/s9", { name: "Sunil", shopId: "s2", pin: "4444" })).status, 200);   // owner resets the PIN
  assert.equal((await raw(tok, "GET", "/data")).status, 403);                                                             // the old session stops working
  const un2 = await unlock("4444"); assert.equal(un2.status, 200);
  assert.equal((await call("owner", "PUT", "/items/staff/s9", { name: "Sunil", shopId: "s2", active: false })).status, 200);   // leaves the job
  assert.equal((await raw(un2.body.token, "GET", "/data")).status, 403); assert.equal((await unlock("4444")).status, 403);
  for (let i = 0; i < 5; i++) await unlock("1357");                                                                       // lockout after 5 wrong tries
  assert.equal((await unlock("1111")).status, 429);
  mem.set("LOCK#s@x.com|staff", { pk: "LOCK#s@x.com", sk: "staff", count: 0, until: 0 });
  for (const id of ["s9", "s10"]) await call("owner", "DELETE", `/items/staff/${id}`);
  const log = (await call("owner", "GET", "/audit")).body.audit.filter((x) => x.col === "staff"); assert.ok(log.some((x) => /PIN set for Sunil/.test(x.text)));
});

test("first screen: shop names are public (names only), everything else still needs a login", async () => {
  const r = await h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/public/shops", headers: {}, queryStringParameters: {} });
  assert.equal(r.statusCode, 200); const b = JSON.parse(r.body);
  assert.ok(Array.isArray(b.shops) && b.shops.length >= 1); assert.deepEqual(Object.keys(b.shops[0]).sort(), ["id", "mgr", "name"]);   // names and whether a shop login exists, nothing else
  const noAuth = await h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/data", headers: {}, queryStringParameters: {} });
  assert.equal(noAuth.statusCode, 401);
});

test("business name: owner renames it any time; it shows on the public first screen", async () => {
  const pub = async () => JSON.parse((await h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/public/shops", headers: {}, queryStringParameters: {} })).body);
  assert.equal((await pub()).business, "My Business");
  assert.equal((await call("sales", "PUT", "/business", { name: "Hack" })).status, 403);
  assert.equal((await call("aud", "PUT", "/business", { name: "Hack" })).status, 403);
  assert.equal((await call("owner", "PUT", "/business", { name: "<script>" })).status, 400);
  assert.equal((await call("owner", "PUT", "/business", { name: "Sri Lakshmi Wines" })).status, 200);
  assert.equal((await pub()).business, "Sri Lakshmi Wines");
  assert.equal((await call("owner", "GET", "/data")).body.business, "Sri Lakshmi Wines");
  await call("owner", "PUT", "/business", { name: "My Business" });
});

test("starting stock date: salesman cannot enter on or before it, can enter the day after; owner sets it", async () => {
  const loc = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
  const back = (n) => new Date(Date.parse(loc + "T00:00:00Z") - n * 864e5).toISOString().slice(0, 10);
  const start = back(3);
  assert.equal((await call("sales", "PUT", "/items/shops/main", { name: "X", startDate: start })).status, 403);
  const r = await call("owner", "PUT", "/items/shops/main", { name: "Main", startDate: start });
  assert.equal(r.status, 200); assert.equal((r.body.item || r.body).startDate, start);
  const row = { shopId: "main", brandId: "b1", received: 0, closing: 5, staff: "Ravi" };
  assert.equal((await call("sales", "PUT", `/items/daily/${start}_b1`, row)).status, 403);
  assert.equal((await call("sales", "PUT", `/items/daily/${back(2)}_b1`, row)).status, 200);
});

test("one person who is both owner and auditor can switch to the auditor view (X-Act-As); nobody else can", async () => {
  const hit = (tok, extra) => h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/data", headers: { authorization: "Bearer " + tok, "x-owner-pin": PIN, ...extra }, queryStringParameters: {} }).then((r) => JSON.parse(r.body));
  assert.equal((await hit("both", {})).me.role, "owner");
  assert.equal((await hit("both", { "x-act-as": "auditor", "x-owner-pin": AUDPIN })).me.role, "auditor");
  assert.equal((await hit("owner", { "x-act-as": "auditor" })).me.role, "owner");   // owner only: header ignored
  assert.equal((await hit("aud", { "x-act-as": "owner", "x-owner-pin": AUDPIN })).me.role, "auditor");      // cannot upgrade
});

test("a salesman PIN from another shop is refused at unlock, and he only ever receives his own shop", async () => {
  await call("owner", "PUT", "/items/shops/s2", { name: "Second" });
  mem.set("STAFF|st9", { pk: "STAFF", sk: "st9", id: "st9", shopId: "s2", name: "Kiran", active: true, pinHash: hashPin("2222"), pv: 1 });
  const unlock = (pin, shopId) => h({ requestContext: { http: { method: "POST" } }, rawPath: "/api/staff/unlock", headers: { authorization: "Bearer sales" }, body: JSON.stringify({ pin, shopId }) }).then((r) => ({ status: r.statusCode, body: JSON.parse(r.body) }));
  assert.equal((await unlock("2222", "main")).status, 403);       // Kiran's PIN on the Main shop screen
  const ok = await unlock("2222", "s2");
  assert.equal(ok.status, 200); assert.equal(ok.body.staff.shopId, "s2");
});

test("salesman picks who worked from his own shop's list; the PIN holder is recorded as who typed it", async () => {
  mem.set("STAFF|st5", { pk: "STAFF", sk: "st5", id: "st5", shopId: "main", name: "Mani", active: true, pv: 1 });
  const d = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Kolkata" }).format(new Date());
  const put = (staff) => call("sales", "PUT", `/items/daily/${d}_b1`, { shopId: "main", brandId: "b1", received: 0, closing: 3, staff });
  assert.equal((await put("Kiran")).status, 400);                 // belongs to the other shop
  assert.equal((await put("Nobody")).status, 400);
  const r = await put("Mani");
  assert.equal(r.status, 200); assert.equal((r.body.item || r.body).staff, "Mani"); assert.equal((r.body.item || r.body).by, "Ravi");
  assert.equal(((await put("")).body.item || {}).staff, "Ravi");
});

test("PIN-only sign-in: owner, auditor and salesman get a session from their PIN, no email or password", async () => {
  const pinLogin = (b) => h({ requestContext: { http: { method: "POST" } }, rawPath: "/api/auth/pin", headers: {}, body: JSON.stringify(b) }).then((r) => ({ status: r.statusCode, body: JSON.parse(r.body) }));
  const get = (tok, extra) => h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/data", headers: { authorization: "Bearer " + tok, ...extra }, queryStringParameters: {} }).then((r) => ({ status: r.statusCode, body: JSON.parse(r.body) }));
  const o = await pinLogin({ role: "owner", pin: PIN });
  assert.equal(o.status, 200);
  assert.equal((await get(o.body.token, {})).status, 403);                                  // a session alone is not enough: the PIN is needed too
  const d = await get(o.body.token, { "x-owner-pin": PIN });
  assert.equal(d.status, 200); assert.equal(d.body.me.role, "owner");
  assert.equal((await pinLogin({ role: "auditor", pin: PIN })).status, 403);               // the owner PIN does not open the auditor's side
  const a = await pinLogin({ role: "auditor", pin: AUDPIN });
  assert.equal((await get(a.body.token, { "x-owner-pin": AUDPIN })).body.me.role, "auditor");
  const s = await pinLogin({ role: "salesman", pin: "1111", shopId: "main" });
  assert.equal(s.status, 200); assert.equal(s.body.staff.name, "Ravi");
  const sd = await get(s.body.token, { "x-staff-token": s.body.staffToken });
  assert.equal(sd.status, 200); assert.equal(sd.body.me.role, "salesman");
  assert.equal((await get(s.body.token, {})).status, 403);                                  // no PIN proof, no data
  assert.equal((await pinLogin({ role: "salesman", pin: "1111", shopId: "s2" })).status, 403);   // PIN of another shop
  assert.equal((await get(o.body.token.slice(0, -2) + "xx", { "x-owner-pin": PIN })).status, 401); // forged
  for (let i = 0; i < 5; i++) await pinLogin({ role: "owner", pin: "00000" + i });
  assert.equal((await pinLogin({ role: "owner", pin: PIN })).status, 429);                 // locked for 15 minutes
});

test("the owner controls every PIN: sets the auditor's and his own in the app; rules are enforced; a redeploy reset restores the deploy-time PINs", async () => {
  mem.delete("LOCK#pinlogin|owner"); mem.delete("LOCK#pinlogin|auditor");
  assert.equal((await call("aud", "PUT", "/pins", { role: "auditor", pin: "135790" })).status, 403);            // only the owner
  assert.equal((await call("owner", "PUT", "/pins", { role: "auditor", pin: "12" })).status, 400);             // 6 to 8 digits
  mem.set("STAFF|st77", { pk: "STAFF", sk: "st77", id: "st77", shopId: "main", name: "Zed", active: true, pinHash: hashPin("111111"), pv: 1 });
  assert.equal((await call("owner", "PUT", "/pins", { role: "auditor", pin: "111111" })).status, 409);
  assert.equal((await call("owner", "PUT", "/pins", { role: "auditor", pin: "135790" })).status, 200);
  assert.equal((await call("aud", "GET", "/data", undefined, AUDPIN)).status, 403);                           // the old auditor PIN stops working at once
  assert.equal((await call("aud", "GET", "/data", undefined, "135790")).status, 200);
  assert.equal((await call("owner", "PUT", "/items/staff/st78", { name: "Y", shopId: "main", pin: "135790" })).status, 409);   // new reserved PIN too
  assert.equal((await call("owner", "PUT", "/pins", { role: "owner", pin: "864209" })).status, 200);
  assert.equal((await call("owner", "PUT", "/pins", { role: "auditor", pin: "864209" }, "864209")).status, 409);   // the auditor cannot share the owner's PIN
  assert.equal((await call("owner", "GET", "/pins", undefined, "864209")).body.auditorSet, true);
  assert.equal((await call("owner", "GET", "/pins", undefined, PIN)).status, 403);                             // old owner PIN gone
  const log = await call("owner", "GET", "/audit", undefined, "864209"); assert.ok(log.body.audit.some((x) => /Auditor PIN changed/.test(x.text)) && !JSON.stringify(log.body).includes("135790"));
  // forgotten PIN: redeploy with a new PinReset value
  process.env.PIN_RESET = "r1";
  const h2 = makeHandler({ db, idp, verify, ownerPin: PIN, auditorPin: AUDPIN, store, files, staffSecret: "testsecret" });
  const r = await h2({ requestContext: { http: { method: "POST" } }, rawPath: "/api/auth/pin", headers: {}, body: JSON.stringify({ role: "owner", pin: PIN }) });
  assert.equal(r.statusCode, 200);
  delete process.env.PIN_RESET;
});

test("shop login: the admin gives a shop its own PIN; that login sees and changes only its own shop", async () => {
  mem.delete("LOCK#pinlogin|owner");
  await call("owner", "PUT", "/items/shops/s2", { name: "Second" });
  await call("owner", "PUT", "/items/brands/b2x", { shopId: "s2", serial: 1, name: "Beer", size: 650, mrp: 150, open: 5, min: 2 });
  const asOwner = await call("owner", "PUT", "/items/shops/main", { name: "Main Shop", mgrPin: "445566" });
  assert.equal(asOwner.status, 200); assert.equal(JSON.stringify(asOwner.body).includes("445566"), false); assert.ok(!JSON.stringify(asOwner.body).includes("mgrPinHash"));
  assert.equal((await call("owner", "PUT", "/items/shops/s2", { name: "Second", mgrPin: "445566" })).status, 409);   // two shops cannot share a PIN
  assert.equal((await call("owner", "PUT", "/items/shops/s2", { name: "Second", mgrPin: "12" })).status, 400);
  assert.equal((await call("owner", "PUT", "/items/staff/sq", { name: "Q", shopId: "main", pin: "445566" })).status, 409);   // a salesman cannot reuse it either
  const pubShops = JSON.parse((await h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/public/shops", headers: {}, queryStringParameters: {} })).body);
  assert.equal(pubShops.shops.find((x) => x.id === "main").mgr, true); assert.equal(pubShops.shops.find((x) => x.id === "s2").mgr, false);
  const pl = (b) => h({ requestContext: { http: { method: "POST" } }, rawPath: "/api/auth/pin", headers: {}, body: JSON.stringify(b) }).then((r) => ({ status: r.statusCode, body: JSON.parse(r.body) }));
  assert.equal((await pl({ role: "shop", shopId: "s2", pin: "445566" })).status, 403);     // shop without a login
  assert.equal((await pl({ role: "shop", shopId: "main", pin: "000000" })).status, 403);
  const sl = await pl({ role: "shop", shopId: "main", pin: "445566" });
  assert.equal(sl.status, 200); assert.equal(sl.body.role, "shop"); assert.equal(sl.body.shop, "main");
  const call2 = (method, path, body, q) => h({ requestContext: { http: { method } }, rawPath: "/api" + path, headers: { authorization: "Bearer " + sl.body.token, "x-owner-pin": "445566" }, body: body ? JSON.stringify(body) : undefined, queryStringParameters: q || {} }).then((r) => ({ status: r.statusCode, body: JSON.parse(r.body) }));
  const d = await call2("GET", "/data");
  assert.equal(d.status, 200); assert.equal(d.body.me.scope, "main");
  assert.ok(d.body.shops.every((x) => x.id === "main") && d.body.brands.every((x) => (x.shopId || "main") === "main") && d.body.staff.every((x) => (x.shopId || "main") === "main"));
  assert.equal((await call2("PUT", "/items/brands/b2x", { shopId: "s2", name: "Hijack", mrp: 1 })).status, 403);          // another shop's brand
  assert.equal((await call2("PUT", "/items/brands/new1", { shopId: "s2", name: "X", mrp: 1, serial: 1 })).status, 403);
  assert.equal((await call2("PUT", "/items/brands/new2", { shopId: "main", name: "Mine", mrp: 100, serial: 9, open: 3 })).status, 200);   // own shop is fine
  assert.equal((await call2("PUT", "/items/shops/s2", { name: "Renamed" })).status, 403);                                  // shops belong to the admin
  assert.equal((await call2("PUT", "/items/shops/main", { name: "Renamed", mgrPin: "778899" })).status, 403);
  assert.equal((await call2("DELETE", "/items/shops/main")).status, 403);
  assert.equal((await call2("PUT", `/items/daily/${today}_b1`, { shopId: "s2", brandId: "b1", closing: 1 })).status, 403);
  assert.equal((await call2("PUT", `/items/cash/${today}_s2`, { upi: 5, den: {} })).status, 403);
  assert.equal((await call2("PUT", "/items/staff/zz1", { name: "Z", shopId: "s2" })).status, 403);
  assert.equal((await call2("PUT", "/items/staff/zz2", { name: "Own", shopId: "main", pin: "908172" })).status, 200);       // his own salesman and PIN
  assert.equal((await call2("GET", "/invoices", undefined, { shop: "s2" })).status, 200);                                   // forced to own shop
  assert.equal((await call2("GET", "/invoices/s2/" + today + "/aaaaaaaaaaaa")).status, 403);
  for (const [m, pth, b] of [["PUT", "/business", { name: "Hack" }], ["PUT", "/pins", { role: "auditor", pin: "135791" }], ["GET", "/backup/status"], ["GET", "/pins"]]) assert.equal((await call2(m, pth, b)).status, 403, pth);
  const log = await call2("GET", "/audit"); assert.equal(log.status, 200); assert.ok(log.body.audit.every((x) => x.shopId === "main"));
  assert.equal((await h({ requestContext: { http: { method: "GET" } }, rawPath: "/api/data", headers: { authorization: "Bearer " + sl.body.token }, queryStringParameters: {} })).statusCode, 403);   // no PIN header
  // switching the shop login off signs it out
  assert.equal((await call("owner", "PUT", "/items/shops/main", { name: "Main Shop", mgrPin: null })).status, 200);
  assert.equal((await call2("GET", "/data")).status, 403);
});

/* ---------- customers (tenants) onboarded by the Admin ---------- */
const ADMPIN = "13572468";
const hT = makeHandler({ db, idp, verify, ownerPin: PIN, auditorPin: AUDPIN, adminPin: ADMPIN, store, files, staffSecret: "testsecret" });
const callT = async (tenant, method, path, body, hdr = {}) => {
  const r = await hT({ requestContext: { http: { method } }, rawPath: "/api" + path, headers: { ...(tenant ? { "x-tenant": tenant } : {}), ...hdr }, body: body ? JSON.stringify(body) : undefined, queryStringParameters: {} });
  return { status: r.statusCode, body: JSON.parse(r.body) };
};
test("customers: admin onboards a customer with several shops; data is isolated from every other customer", async () => {
  assert.equal((await callT("", "POST", "/admin/login", { pin: "00000000" })).status, 403);
  const lg = await callT("", "POST", "/admin/login", { pin: ADMPIN }); assert.equal(lg.status, 200);
  const A = { authorization: "Bearer " + lg.body.token, "x-admin-pin": ADMPIN };
  assert.equal((await callT("", "GET", "/admin/tenants")).status, 401);
  assert.equal((await callT("", "GET", "/admin/tenants", null, { authorization: A.authorization })).status, 403);
  // validation
  assert.equal((await callT("", "PUT", "/admin/tenants/Ab", { name: "x", ownerPin: "654321" }, A)).status, 400);
  assert.equal((await callT("", "PUT", "/admin/tenants/kumar", { name: "Kumar Group" }, A)).status, 400);
  assert.equal((await callT("", "PUT", "/admin/tenants/kumar", { name: "Kumar Group", ownerPin: ADMPIN }, A)).status, 400);
  assert.equal((await callT("", "PUT", "/admin/tenants/kumar", { name: "Kumar Group", ownerPin: "654321", auditorPin: "654321" }, A)).status, 400);
  assert.equal((await callT("", "PUT", "/admin/tenants/kumar", { name: "Kumar Group", ownerPin: "654321", auditorPin: "777888" }, A)).status, 200);
  assert.equal((await callT("", "PUT", "/admin/tenants/rao", { name: "Rao Liquors", ownerPin: "112233" }, A)).status, 200);
  assert.equal((await callT("ghost", "GET", "/public/shops")).status, 404);
  // public page of the customer
  assert.equal((await callT("kumar", "GET", "/public/shops")).body.business, "Kumar Group");
  // owner of kumar signs in with ITS pin only
  assert.equal((await callT("kumar", "POST", "/auth/pin", { role: "owner", pin: PIN })).status, 403);          // default customer's PIN does not work
  assert.equal((await callT("kumar", "POST", "/auth/pin", { role: "owner", pin: "112233" })).status, 403);    // another customer's PIN neither
  const ko = await callT("kumar", "POST", "/auth/pin", { role: "owner", pin: "654321" }); assert.equal(ko.status, 200);
  const KO = { authorization: "Bearer " + ko.body.token, "x-owner-pin": "654321" };
  for (const [id, nm] of [["s1", "Kumar Main"], ["s2", "Kumar Highway"]]) assert.equal((await callT("kumar", "PUT", "/items/shops/" + id, { name: nm }, KO)).status, 200);
  assert.equal((await callT("kumar", "PUT", "/items/brands/bk1", { shopId: "s1", serial: 1, name: "KBrand", size: 750, mrp: 300, open: 5, min: 1 }, KO)).status, 200);
  assert.deepEqual((await callT("kumar", "GET", "/public/shops")).body.shops.map((x) => x.name), ["Kumar Main", "Kumar Highway"]);
  assert.equal((await callT("kumar", "GET", "/data", null, KO)).body.brands.length, 1);
  // rao sees none of it; kumar's token is useless there
  const ro = await callT("rao", "POST", "/auth/pin", { role: "owner", pin: "112233" }); assert.equal(ro.status, 200);
  const RO = { authorization: "Bearer " + ro.body.token, "x-owner-pin": "112233" };
  const rd = (await callT("rao", "GET", "/data", null, RO)).body; assert.equal(rd.brands.length, 0); assert.equal(rd.shops.length, 0);
  assert.equal((await callT("rao", "GET", "/data", null, { authorization: KO.authorization, "x-owner-pin": "654321" })).status >= 400, true);
  assert.equal((await callT("rao", "GET", "/data", null, { authorization: KO.authorization, "x-owner-pin": "112233" })).status >= 400, true);
  // the original (default) customer is untouched and sees none of the new rows
  const def = await call("owner", "GET", "/data"); assert.equal(def.body.brands.some((b) => b.id === "bk1"), false);
  assert.equal((await callT("", "GET", "/public/shops")).body.shops.some((x) => x.name === "Kumar Main"), false);
  // the customer owner can run his own PINs and a salesman with his own PIN, locked to his tenant
  assert.equal((await callT("kumar", "PUT", "/items/staff/st9", { shopId: "s2", name: "Mani", pin: "445566" }, KO)).status, 200);
  assert.equal((await callT("kumar", "POST", "/auth/pin", { role: "salesman", pin: "445566", shopId: "s2" })).status, 200);
  assert.equal((await callT("rao", "POST", "/auth/pin", { role: "salesman", pin: "445566", shopId: "s2" })).status, 403);
  // admin overview, then switch a customer off
  const ls = await callT("", "GET", "/admin/tenants", null, A);
  assert.deepEqual(ls.body.tenants.find((t) => t.code === "kumar").shops.sort(), ["Kumar Highway", "Kumar Main"]);
  assert.equal((await callT("", "PUT", "/admin/tenants/kumar", { active: false }, A)).status, 200);
  assert.equal((await callT("kumar", "GET", "/public/shops")).status, 403);
  assert.equal((await callT("", "PUT", "/admin/tenants/kumar", { active: true, ownerPin: "909090" }, A)).status, 200);   // reset owner PIN too
  assert.equal((await callT("kumar", "POST", "/auth/pin", { role: "owner", pin: "654321" })).status, 403);
  assert.equal((await callT("kumar", "POST", "/auth/pin", { role: "owner", pin: "909090" })).status, 200);
  // admin session without the PIN header is refused; a customer owner token is not an admin
  assert.equal((await callT("", "GET", "/admin/tenants", null, { authorization: A.authorization })).status, 403);
  assert.equal((await callT("", "GET", "/admin/tenants", null, { authorization: KO.authorization, "x-admin-pin": ADMPIN })).status, 401);
});

test("owner can mark and undo bank receipts (bankOnly) without touching the collection; a normal save never changes them", async () => {
  const d = new Date(Date.now() - 20 * 864e5).toISOString().slice(0, 10), id = `${d}_main`;
  assert.equal((await call("owner", "PUT", "/items/cash/" + id, { upi: 100, den: { 500: 4 } })).status, 200);
  const r = await call("owner", "PUT", "/items/cash/" + id, { bankOnly: true, upi: 1, den: { 500: 99 }, cashBank: { amount: 1500 }, upiBank: { amount: 100 } });
  assert.equal(r.status, 200); assert.equal(r.body.item?.cashBank?.amount ?? r.body.cashBank?.amount, 1500);
  const row = (await call("owner", "GET", "/data")).body.cash.find((c) => c.id === id);
  assert.equal(row.cash, 2000); assert.equal(row.upi, 100); assert.equal(row.cashBank.amount, 1500); assert.equal(row.upiBank.amount, 100);   // collection untouched
  await call("owner", "PUT", "/items/cash/" + id, { upi: 100, den: { 500: 4 }, cashBank: { amount: 0 } });                                  // normal save cannot change the bank mark
  assert.equal((await call("owner", "GET", "/data")).body.cash.find((c) => c.id === id).cashBank.amount, 1500);
  await call("owner", "PUT", "/items/cash/" + id, { bankOnly: true, cashBank: null });
  assert.equal((await call("owner", "GET", "/data")).body.cash.find((c) => c.id === id).cashBank, null);
  assert.equal((await call("sales", "PUT", "/items/cash/" + id, { bankOnly: true, cashBank: { amount: 5 } })).status >= 200, true);
  assert.equal((await call("owner", "GET", "/data")).body.cash.find((c) => c.id === id).cashBank, null);   // a salesman cannot set bank marks
});

test("stock transfer: out of one shop (not a sale), received in the other, brand auto-created, undo, permissions", async () => {
  const d = new Date().toISOString().slice(0, 10);
  assert.equal((await call("owner", "PUT", "/items/shops/xa", { name: "Shop XA" })).status, 200);
  assert.equal((await call("owner", "PUT", "/items/shops/xb", { name: "Shop XB" })).status, 200);
  assert.equal((await call("owner", "PUT", "/items/brands/xbr", { shopId: "xa", serial: 1, name: "Old Monk", size: 750, mrp: 700, open: 50, min: 5 })).status, 200);
  assert.equal((await call("owner", "POST", "/transfer", { date: d, fromShop: "xa", toShop: "xa", brandId: "xbr", qty: 3 })).status, 400);
  assert.equal((await call("owner", "POST", "/transfer", { date: d, fromShop: "xa", toShop: "xb", brandId: "xbr", qty: 0 })).status, 400);
  assert.equal((await call("aud", "POST", "/transfer", { date: d, fromShop: "xa", toShop: "xb", brandId: "xbr", qty: 3 })).status, 403);
  const r = await call("owner", "POST", "/transfer", { date: d, fromShop: "xa", toShop: "xb", brandId: "xbr", qty: 6, note: "to cover weekend" });
  assert.equal(r.status, 200); assert.equal(r.body.rows[0].out, 6); assert.equal(r.body.rows[1].tin, 6); assert.equal(r.body.brand.shopId, "xb"); assert.equal(r.body.brand.pending, true);
  const data = (await call("owner", "GET", "/data")).body;
  assert.equal(data.daily.find((x) => x.shopId === "xa" && x.brandId === "xbr").out, 6);
  assert.equal(data.daily.find((x) => x.shopId === "xb").tin, 6);
  assert.equal(data.transfers.length >= 1, true);
  // a second transfer reuses the brand created in the other shop
  const r2 = await call("owner", "POST", "/transfer", { date: d, fromShop: "xa", toShop: "xb", brandId: "xbr", qty: 4 });
  assert.equal(r2.body.brand, undefined); assert.equal(r2.body.rows[0].out, 10); assert.equal(r2.body.rows[1].tin, 10);
  // saving the day's stock entry never wipes the transfer figures
  const sv = await call("owner", "PUT", `/items/daily/${d}_xbr`, { shopId: "xa", brandId: "xbr", name: "Old Monk", size: 750, mrp: 700, received: 2, closing: 30, tin: 0, out: 0 });
  assert.equal(sv.body.item.out, 10); assert.equal(sv.body.item.received, 2);
  // undo
  const u = await call("owner", "DELETE", `/transfer/${d}/${r2.body.transfer.id}`);
  assert.equal(u.status, 200); assert.equal(u.body.rows[0].out, 6); assert.equal(u.body.rows[1].tin, 6);
  // a salesman can send only from his own shop and sees the other shops by name only
  const sd = (await call("sales", "GET", "/data")).body; assert.ok(Array.isArray(sd.peers));
  assert.equal((await call("sales", "POST", "/transfer", { date: d, fromShop: "xa", toShop: "xb", brandId: "xbr", qty: 1 })).status, 403);
});

test("Shop login lists customers and their shops; the admin can hide or switch one off", async () => {
  const lg = await callT("", "POST", "/admin/login", { pin: ADMPIN }), A = { authorization: "Bearer " + lg.body.token, "x-admin-pin": ADMPIN };
  const l1 = (await callT("", "GET", "/public/customers")).body.customers;
  assert.ok(l1.some((c) => c.code === "rao" && c.name === "Rao Liquors"));
  assert.ok(l1.some((c) => c.code === "" ));                                                   // the original business is listed too
  assert.deepEqual(l1.find((c) => c.code === "kumar").shops.sort(), ["Kumar Highway", "Kumar Main"]);
  assert.equal(JSON.stringify(l1).includes("Hash"), false);                                    // nothing secret is exposed
  await callT("", "PUT", "/admin/tenants/rao", { listed: false }, A);
  assert.equal((await callT("", "GET", "/public/customers")).body.customers.some((c) => c.code === "rao"), false);
  assert.equal((await callT("rao", "GET", "/public/shops")).status, 200);                      // hidden from the list, but the code still works
  await callT("", "PUT", "/admin/tenants/kumar", { active: false }, A);
  assert.equal((await callT("", "GET", "/public/customers")).body.customers.some((c) => c.code === "kumar"), false);
  await callT("", "PUT", "/admin/tenants/kumar", { active: true }, A);
});

test("original business: Admin sets its owner/auditor PINs (no deploy-time PINs needed); stored PINs win; old data untouched", async () => {
  const lg = await callT("", "POST", "/admin/login", { pin: ADMPIN });
  const A = { authorization: "Bearer " + lg.body.token, "x-admin-pin": ADMPIN };
  const ls = (await callT("", "GET", "/admin/tenants", null, A)).body.tenants;
  assert.equal(ls[0].code, "main"); assert.equal(ls[0].isMain, true); assert.equal(ls[0].ownerSet, true);   // env PIN counts as set
  assert.equal((await callT("", "PUT", "/admin/tenants/main", { ownerPin: ADMPIN }, A)).status, 400);       // not the admin PIN
  assert.equal((await callT("", "PUT", "/admin/tenants/main", { ownerPin: "909090", auditorPin: "909090" }, A)).status, 400);
  assert.equal((await callT("", "PUT", "/admin/tenants/main", { auditorPin: PIN }, A)).status, 400);        // equals the env owner PIN
  assert.equal((await callT("", "PUT", "/admin/tenants/main", { ownerPin: "909091", auditorPin: "909092" }, A)).status, 200);
  assert.equal((await callT("", "POST", "/auth/pin", { role: "owner", pin: "909091" })).status, 200);       // new PIN works
  assert.equal((await callT("", "POST", "/auth/pin", { role: "owner", pin: PIN })).status, 403);            // env PIN replaced
  assert.equal((await callT("", "POST", "/auth/pin", { role: "auditor", pin: "909092" })).status, 200);
  const oo = await callT("", "POST", "/auth/pin", { role: "owner", pin: "909091" });
  const d = await callT("", "GET", "/data", null, { authorization: "Bearer " + oo.body.token, "x-owner-pin": "909091" });
  assert.equal(d.status, 200); assert.equal(d.body.brands.some((b) => b.id === "bk1"), false);              // data intact, no tenant rows leaked
  // listing toggle
  assert.equal((await callT("", "GET", "/public/customers")).body.customers.some((c) => c.code === ""), true);
  assert.equal((await callT("", "PUT", "/admin/tenants/main", { listed: false }, A)).status, 200);
  assert.equal((await callT("", "GET", "/public/customers")).body.customers.some((c) => c.code === ""), false);
  assert.equal((await callT("", "PUT", "/admin/tenants/main", { listed: true }, A)).status, 200);
});

test("Admin renames and adds shops of a customer and of the original business; shop PIN status shown", async () => {
  const lg = await callT("", "POST", "/admin/login", { pin: ADMPIN });
  const A = { authorization: "Bearer " + lg.body.token, "x-admin-pin": ADMPIN };
  assert.equal((await callT("", "PUT", "/admin/tenants/rao2", { name: "Rao Two", ownerPin: "313131" }, A)).status, 200);
  let rows = (await callT("", "GET", "/admin/tenants", null, A)).body.tenants;
  let rao = rows.find((t) => t.code === "rao2");
  assert.equal(rao.ownerSet, true); assert.equal(rao.auditorSet, false); assert.deepEqual(rao.shopList, [{ id: "main", name: "Rao Two" }]);
  assert.equal((await callT("", "PUT", "/admin/tenants/rao2/shops/main", { name: "Rao Main Road" }, A)).status, 200);   // rename the implicit shop
  assert.equal((await callT("rao2", "GET", "/public/shops")).body.shops[0].name, "Rao Main Road");
  assert.equal((await callT("", "PUT", "/admin/tenants/rao2/shops/s77", { name: "Rao Highway" }, A)).status, 200);      // add a second shop
  assert.deepEqual((await callT("rao2", "GET", "/public/shops")).body.shops.map((x) => x.name).sort(), ["Rao Highway", "Rao Main Road"]);
  assert.equal((await callT("", "PUT", "/admin/tenants/rao2/shops/s77", { name: "Rao Bypass" }, A)).status, 200);       // rename it
  assert.equal((await callT("rao2", "GET", "/public/shops")).body.shops.some((x) => x.name === "Rao Bypass"), true);
  assert.equal((await callT("", "PUT", "/admin/tenants/rao2/shops/s77", { name: "" }, A)).status, 400);
  assert.equal((await callT("", "PUT", "/admin/tenants/nope/shops/s1", { name: "x" }, A)).status, 404);
  assert.equal((await callT("", "PUT", "/admin/tenants/rao2/shops/s9", { name: "x" })).status, 401);                    // no admin sign-in
  // the original business too
  assert.equal((await callT("", "PUT", "/admin/tenants/main/shops/sm1", { name: "Original Second" }, A)).status, 200);
  const main = (await callT("", "GET", "/admin/tenants", null, A)).body.tenants.find((t) => t.code === "main");
  assert.equal(main.shopList.some((x) => x.name === "Original Second"), true);
  // renaming must keep the shop's own data (here: a brand stays attached)
  assert.equal(rao.code, "rao2");
});

