# Backing up and restoring your sales data

Your sales data lives in one DynamoDB table. This app protects it in four ways. The first two need nothing from you.

| Layer | What it does | Who runs it | Cost |
|---|---|---|---|
| 1. **Nightly automatic backup** | A small job copies the whole table to a private S3 bucket at **3:00 am IST** every night. Copies are kept 90 days, then deleted. | AWS (automatic) | Lambda and the schedule are free. S3 holds a few MB in total, a fraction of a cent a month |
| 2. **Back up now** | Owner button on the Shops tab. Takes a copy straight away, for example before a big change. | Owner | Same as above |
| 3. **Download full backup (.json)** | Saves a copy to your phone or computer. Keep it in Google Drive or email it to yourself once a month. This is your protection if the AWS account itself is ever lost. | Owner | Free |
| 4. **Excel reports (CSV)** | **Sales summary** (one row per day per shop) and **Brand-wise detail** (opening, received, closing, sale qty, amount) for the period you pick. Open in Excel or Google Sheets. | Owner | Free |

The Shops tab shows **✅ Last automatic backup: 8 Oct 2026, 3:00 am** in green. If no backup has run for more than 36 hours it turns red.

## What is and is not backed up
* **Backed up:** shops, brands, MRP, opening stock, daily stock entries, UPI and cash collections, bank marks, loans and expenses.
* **Not backed up:** user accounts and passwords (they live in Cognito). If they are lost, just invite the users again from the Shops tab. To keep a list: `aws cognito-idp list-users --user-pool-id <UserPoolId> --region ap-south-1 > users.json`.
* The website code is in the zip you deployed from. Keep that zip.

## Where the nightly backups are
S3 bucket named in the stack outputs as **BackupBucketName**, in folders `backups/2026-10-08/030000.json.gz`.
```bash
aws s3 ls s3://<BackupBucketName>/backups/ --recursive --region ap-south-1
aws s3 cp s3://<BackupBucketName>/backups/2026-10-08/213000.json.gz . --region ap-south-1
```
(File times are UTC: 21:30 UTC is 3:00 am IST.) You can also browse and download them in the AWS console under S3.

## Restore (after a mistake or data loss)
1. Get a backup file: a nightly one from S3, or a `.json` you downloaded from the app.
2. Open **AWS CloudShell** (the `>_` icon), choose **Actions, Upload file**, and upload the backup and the project's `tools/restore.py`.
3. Look at the backup first (changes nothing):
```bash
python3 restore.py liquor-backup-2026-10-08.json.gz --dry-run
```
It prints the date and how many shops, brands, daily records and so on it contains.
4. Restore into the live table (the name is on the CloudFormation stack's **Resources** tab, row `Table`):
```bash
python3 restore.py liquor-backup-2026-10-08.json.gz --table <TableName> --region ap-south-1
```
Type `yes` when asked. It writes gently (about 10 records a second) because the free-tier table has small capacity: 5,000 records takes roughly 8 minutes.

**What restore does:** it puts every record from the file back, overwriting records with the same key. It never deletes anything, so entries made after the backup was taken stay. To go back to exactly the backup's state, restore into a **new** table and point the app at it, or ask for help.

Test your restore once, right after the first deploy, so you know it works before you need it.

## Good habits
* Check the green "Last automatic backup" line when you open the Shops tab.
* Download the full backup (.json) on the 1st of every month and keep it outside AWS.
* Press **Back up now** before bulk changes (new MRP for many brands, deleting a shop).
* If you ever stop using the app, run `./destroy.sh` without `--delete-data` first and keep the backup bucket.

## Limits to know
* A busy shop with 40 brands adds about 15,000 records a year. **Back up now** and the download comfortably handle well over 100,000 records (a few seconds of work); the nightly job has even more time.
* Very large downloads (over about 5 MB) are sent compressed automatically and still arrive as one `.json` file.
* DynamoDB's own point-in-time recovery and managed backups are **not** used because they are not part of the free tier.
* A backup protects against mistakes and data loss. It does not protect against someone with full AWS access deleting both the table and the backup bucket, which is why the monthly download to your own storage matters.


## Invoice files

The nightly backup and the "Full backup" download contain the invoice records (supplier, number, amount, who uploaded) but **not the photos/PDFs**. Those are in the `InvoiceBucket` S3 bucket, which is kept (not deleted) when you remove the stack. To copy them to your computer:

    aws s3 sync s3://<InvoiceBucketName> ./invoice-files

The bucket name is printed as `InvoiceBucketName` after deploy.
