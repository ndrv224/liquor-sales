# Deploy guide: Liquor Sales Tracker on AWS (free tier)

Time needed: about 30 to 45 minutes the first time. No coding is needed.
Expected cost: **₹0** while you stay inside the always-free limits (a few shops and a few staff). A budget alert emails you at about $0.01 of spend, so you find out the moment anything is charged.

> I built and tested this app and its server code, but I could not deploy it to a live AWS account myself. Your first deploy may show a small error. Section 9 lists the likely ones. If you hit one, copy the exact message and ask for help.

---

## 1. Create your AWS account (skip if you have one)
1. Go to https://aws.amazon.com and choose **Create an AWS account**. Use a business email. You need a phone number and a debit or credit card (AWS only verifies it).
2. When asked to choose a plan, choose the **Free plan**. New accounts get credits and the plan lasts up to 6 months. The always-free services this app uses do not use your credits.
3. **Important:** after 6 months, or when credits run out, the Free plan closes. To keep the shop running, open **Billing and Cost Management, Account plan** and switch to the **Paid plan**. You still pay nothing while inside the always-free limits.
4. Sign in as the root user once, then **turn on MFA** (Account name at top right, Security credentials, Assign MFA device). Do not use the root user for daily work.
5. Pick your region at the top right: **Asia Pacific (Mumbai) ap-south-1**. Use the same region every time.

## 2. Create a deploy user (not the root user)
1. Console, search **IAM**, Users, **Create user**. Name it `deployer`.
2. On permissions choose **Attach policies directly**, tick **AdministratorAccess**, then create the user.
3. Open the user, **Security credentials**, **Create access key**, choose **Command Line Interface (CLI)**, create it, and **download the .csv**. Keep it private. You will delete this key after deploying (step 8).

## 3. Get the tools (choose ONE path)

### Path A: AWS CloudShell (easiest, nothing to install)
1. In the console click the **CloudShell icon** (`>_`) at the top bar. Wait for the terminal. Check the region is Mumbai.
2. Click **Actions, Upload file** and upload `liquor-tracker-aws.zip`.
3. Run:
```bash
unzip liquor-tracker-aws.zip
cd liquor-tracker-aws
pip install --user aws-sam-cli
export PATH="$HOME/.local/bin:$PATH"
sam --version
```
CloudShell is already signed in with your console login, so skip step 4 and the `aws configure` part.

### Path B: Your own computer
1. Install the **AWS CLI v2**: https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html
2. Install the **SAM CLI**: https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html
3. Windows users: run the commands in **Git Bash** or **WSL** (the deploy script is a bash script). Mac and Linux: use Terminal.
4. Check: `aws --version` and `sam --version` both print a version.

## 4. Connect the CLI to your account (Path B only)
```bash
aws configure
```
Enter the access key ID and secret from the .csv, region `ap-south-1`, output format `json`. Check it works:
```bash
aws sts get-caller-identity
```
It should print your account number.

## 5. Choose your owner PIN and emails
In the project folder create a file named `.deploy.env` with one line:
```
OWNER_PIN=246810
```
Use 4 to 12 digits and **do not keep 98765**. Keep this file; the deploy script reads it every time so the PIN never silently resets.

You need two email addresses:
* **Owner email**: your login. Cognito sends the temporary password here.
* **Alert email** (optional but recommended): gets a warning if AWS spending passes 80% of $1 a month.

## 6. Deploy
```bash
cd liquor-tracker-aws
chmod +x deploy.sh
./deploy.sh owner@yourmail.com alerts@yourmail.com
```
It takes about 5 to 10 minutes (CloudFront is the slow part). When it finishes it prints:
```
Deployed: https://dxxxxxxxxxxxx.cloudfront.net
```
Save that address. The first deploy asks nothing else. If you are asked to confirm AWS Budgets email subscription, check the alert mailbox.

## 7. First sign-in and setup
1. Check the owner mailbox (and spam) for a message from `no-reply@verificationemail.com` with a temporary password.
2. Open the address from step 6, tap **Owner**, sign in with the owner email and temporary password, and choose a new password (8+ characters with upper case, lower case and a number).
3. Enter your owner PIN.
4. **🏬 Shops tab**: rename "My Shop" (✏️ Edit) and add other shops.
5. **📦 Brands tab**: add each brand with MRP, size, serial number and **opening stock**. This is the only time opening stock matters; after the first closing, each day opens with the previous day's closing.
6. **🏬 Shops tab, Invite a user**: invite each person by email. Role *Salesman* for the counter staff, role *Auditor* for the person who confirms the bank. Each gets an email with a temporary password and picks their own button (Owner, Auditor or Salesman) on the first screen. Owner and Auditor both use your PIN.
7. **👥 Salesmen tab**: choose a shop at the top and add the names of the people who work there. Salesmen pick their name from this list on every stock entry. Repeat for each shop.
8. **Open on a phone** (see section 10 below): add the address to the home screen.

### Check the backups (2 minutes)
On the Shops tab press **☁️ Back up now**. You should see a green "Last automatic backup" line. Then press **⬇ Full backup (.json)** and keep that file. Read `BACKUP.md` once.

### Quick test (5 minutes)
1. As salesman: Stock Entry, choose your name, type a closing quantity for one brand, enter some UPI and cash notes, add one expense, tap **Submit**. Then upload a photo in **🧾 Invoices**.
2. Check **Day Summary**. Sold, amount, "Worked by" and the "Sale vs collection" line should appear.
3. As auditor: **🏦 Bank** tab, mark UPI and cash received (green "Received to Bank").
4. As owner: Home shows sales, loans pending, cash not yet in bank and purchases; **🧾 Invoices** shows the photo; **🕵️ Activity** lists the entries.

## 8. Lock down and stay free
1. **Delete the deploy access key** (IAM, Users, deployer, Security credentials, Deactivate then Delete). Create a new one only when you need to deploy again.
2. **Billing, Billing preferences**: turn on **Receive Free Tier usage alerts** and **Receive CloudWatch billing alerts**, and enter your email.
3. **Billing, Free Tier**: this page shows your usage against each free limit. Look at it once a month.
4. Do **not** add these (they cost money even when idle): NAT gateways, RDS or Aurora, EC2 servers, load balancers, Route 53 (a custom domain costs about $0.50 a month for the hosted zone), WAF, Secrets Manager.
5. What stays free for this app: Lambda (1 million requests a month), DynamoDB (25 GB and the capacity the template uses), CloudFront (1 TB out and 10 million requests a month), Cognito (first 10,000 monthly users). The tiny S3 storage and deployment bucket cost well under ₹1 a month.

## Everyday operations
| Task | How |
|---|---|
| Add or remove staff logins | Owner, Shops tab, **Invite a user**. To remove or disable someone: Console, Cognito, your user pool, Users |
| Change the owner PIN | Edit `.deploy.env`, run `./deploy.sh owner@yourmail.com` again |
| Update the app after changes | Replace the files, run `./deploy.sh ...` again. Hard refresh the page afterwards |
| Back up data | Automatic every night at 3:00 am. Press **Back up now** or **Download full backup** on the Shops tab any time. Details and restore steps: `BACKUP.md` |
| See errors | Console, CloudWatch, Log groups, the one starting `/aws/lambda/liquor-tracker`. Logs are kept 7 days |
| Someone forgot their password | The app has no "forgot password" screen yet. Reset it in Console, Cognito, your user pool, Users, select the person, **Reset password** (they get a new temporary password by email) |

## Remove everything
```bash
./destroy.sh                 # removes the website and server code, keeps your data
./destroy.sh --delete-data   # also deletes the database and all user accounts
```

## 9. If something goes wrong
| Message or symptom | What to do |
|---|---|
| `Your account must be verified before you can add new CloudFront resources` | New AWS accounts are sometimes held for a day. Open a free support case (Support Center, Create case, Account and billing) asking to enable CloudFront, or wait 24 hours and run the script again |
| Deploy says a service or resource is not available on your plan | Billing, Account plan: switch the Free plan to the **Paid plan** (still ₹0 inside the always-free limits) and redeploy |
| `sam: command not found` | Close and reopen the terminal. In CloudShell run `export PATH="$HOME/.local/bin:$PATH"` |
| `Unable to locate credentials` | Run `aws configure` again (Path B) |
| `The specified cache policy does not exist` | Fixed in this version of the package (a wrong CloudFront policy ID). Use the latest zip and run `./deploy.sh` again; it clears the failed attempt by itself |
| Stack shows `ROLLBACK_COMPLETE` | Open CloudFormation, the stack, **Events**, and read the first red line. Delete the failed stack (`aws cloudformation delete-stack --stack-name liquor-tracker`) and run the script again |
| Page is blank or says the app is not configured | `web/config.js` is empty. Run `./deploy.sh` again |
| No temporary password email | Check spam. Or Console, Cognito, your pool, Users, select the owner, **Reset password** |
| "Owner PIN required" in a loop | PIN mismatch. Check `.deploy.env` and redeploy, then use that PIN |
| "No role assigned" | The user is not in the `owner`, `auditor` or `salesman` group (Cognito, Groups) |
| "This is a salesman account. Please choose Salesman…" | The person pressed the wrong button on the first screen. Choose the button that matches their role |
| 403 from `/api` | Rare: the Function URL permissions did not apply. Redeploy once more |
| Old screen after an update | Hard refresh (Ctrl+Shift+R). The script already clears the CDN cache |

## Invoice papers

Nothing extra to set up: deploy creates a private invoice bucket automatically. Sign in as a salesman, open 🧾 Invoices and upload a test photo; sign in as the owner to view it. See README.md for limits.

## 10. Use it on a mobile phone

The app is a normal web page, so there is nothing to install from a store. Everyone uses the same address that deploy.sh printed (`https://dxxxxxxxxxxxx.cloudfront.net`). Send it to them on WhatsApp.

**Android (Chrome):** open the address, tap the **⋮** menu, then **Add to Home screen** (or **Install app**), then **Add**. An icon appears on the home screen.

**iPhone (Safari):** open the address in **Safari** (not inside WhatsApp), tap the **Share** button, then **Add to Home Screen**, then **Add**.

Then each person:
1. Opens the icon. The first time, tap any role button on the first screen: the app reads the role from the account and opens the right screen by itself.
2. First time only: signs in with the email and the temporary password from their invitation email and chooses a new password.
3. Owner and Auditor enter the PIN. The page locks again after 10 minutes of no use.
4. Salesmen use **📷 Take photo** in the Invoices tab to photograph a bill with the phone camera.

Tips: if the invitation email lands in spam, tell the person to look there. If the phone shows an old screen after an update, close the app and open it again. A phone needs an internet connection to save entries.

After the first sign-in a phone stays signed in for 30 days, so salesmen open straight to Stock Entry. Owner and Auditor only enter the PIN each time they open the app. Use **⎋ Sign out** to switch accounts on a shared phone.

## First screen: one icon per shop

The first screen shows your business name (default **My Business**; the owner can rename it any time in the Shops tab) and one tile per shop. Tap your shop, then choose Owner, Salesman or Auditor, then sign in. The shop you tapped opens first. When the owner adds a shop in the Shops tab, a new tile appears automatically for everyone. Only shop names are visible before sign-in; no figures or staff.

The owner can rename the business in the Shops tab (no redeploy). Optionally set `BUSINESS_NAME` in `.deploy.env` for the initial name. The first shop is called the same name until the owner renames it in the Shops tab.


## Adding any shop at any time (generic setup)
Owner → Shops tab → **Add shop**. Optionally pick **Copy the brand list from** an existing shop: brands are copied with opening stock 0 and flagged pending, so you only set the MRP/opening stock. A new tile appears on the first screen immediately.

## Salesman personal PINs
- Only the **owner** creates a salesman's PIN (👥 Salesmen → Set PIN, 4–8 digits, unique across all staff).
- The salesman signs in with the shared shop email/password once, then enters **his own PIN** each time. The PIN locks him to his shop, and his name is stamped on every entry he saves.
- A salesman cannot enter data until the owner sets his PIN. After redeploying, set PINs for your existing salesmen.
- Resetting or deactivating a PIN signs him out immediately. 5 wrong tries lock for 15 minutes.

## Starting stock and pending dates
1. Owner → **Brands** tab → **Starting stock** card. Pick the date (for example 30-09-2026) and type each brand's stock at the end of that day, then Save. Do this once per shop.
2. Salesmen can enter only from the next day (01-10-2026) onwards. Earlier dates are refused by the server. That day's opening stock is the number you typed.
3. When a salesman opens the app it shows a **Pending dates** list (days since the start with brands not yet closed) and opens the oldest one first. Tap a date to enter it.
4. If no starting date is set for a shop, the salesman is told to ask the owner.

## One person as both Owner and Auditor
Both of your shops (for example KumarWines and Kanagudr Wines) already share one owner account and one auditor account. If the **same person** is both, put that one login in **both** groups: AWS Console → Cognito → your user pool → Users → the user → *Add user to group* → `owner` and `auditor`. After sign-in a button at the top switches between **Switch to Auditor** and **Switch to Owner**. Each view keeps its own rules (only the Auditor view confirms bank receipts), uses the same PIN, and is recorded in the activity log under the same email.

## First screen layout
The first screen has **Owner** and **Auditor** buttons at the top (one account for all shops) and, below them, one **"<Shop name> Sales"** tile per shop for salesmen. Salesmen tap their own shop's tile; owner and auditor just tap their button and pick the shop inside the app.

## Choosing who worked
On every stock entry the salesman must pick **who worked that day** from his shop's list (your PIN holder is preselected). This is shown in the Day Summary and reports. The app also records who typed the entry in (the PIN holder), so a relief salesman's day is still traceable.


## PIN-only sign-in (no email or password)
Nobody types an email or password any more. On the first screen tap **Owner**, **Auditor**, or your shop's **Sales** tile, then enter the PIN.
- **Owner** uses `OWNER_PIN` and **Auditor** uses his own `AUDITOR_PIN`, both in `.deploy.env`. Each must be 6 to 8 digits, different from each other, and not 98765, otherwise `deploy.sh` stops.
- **Salesmen** use their personal PIN, set by the owner in 👥 Salesmen.
- 5 wrong PINs lock that kind of sign-in for 15 minutes. Because the PIN is now the only key, choose 6 digits or more, and never share the owner PIN with salesmen.
- Changing `OWNER_PIN` and redeploying signs every phone out; they just enter the new PIN.
- The Cognito logins from before are no longer used by the app and can be ignored.


## What each role can do
| Role | Signs in with | Can do |
|---|---|---|
| Owner | `OWNER_PIN` | Everything: brands, prices, starting stock, reports, shops, salesmen and their PINs, backups, activity log |
| Auditor | `AUDITOR_PIN` | Only two tabs: **Closing stock** (correct the closing stock of a day the salesman already entered; every change is logged for the owner) and **Bank credits** (view and confirm the amount credited to the bank). No prices, loans, expenses, invoices or salesman list |
| Salesman | His own PIN (set by the owner, unique, never equal to the owner or auditor PIN) | Enter stock and collection for his own shop only |

`.deploy.env` therefore needs both lines, for example:
```
OWNER_PIN=482915
AUDITOR_PIN=739204
```

## The owner controls every PIN
- **Your own PIN and the auditor's:** Owner → **Shops** tab → **🔑 PINs**. Tap *Change* (yours) or *Set / change* (auditor). 6 to 8 digits, and no two people can share a PIN. It works at once and the old PIN stops.
- **Salesmen:** Owner → **👥 Salesmen** → Set PIN.
- The `OWNER_PIN` in `.deploy.env` is only the **starting** PIN. After you change it in the app, the app's PIN is used. `AUDITOR_PIN` in `.deploy.env` is optional; you can set the auditor PIN in the app instead.
- **Forgot your PIN?** Add `RESET_PINS=1` to `.deploy.env` and run `./deploy.sh` again. PINs changed inside the app are cleared and `OWNER_PIN` / `AUDITOR_PIN` from `.deploy.env` work again. Remove the line afterwards so later deploys do not reset them. Salesman PINs are not affected.

## Demo mode (to test or to show another shop)
On the first screen tap **🎬 Try the demo (sample data)**, then pick Owner, Salesman or Auditor. The demo has two sample shops with two weeks of sales, bank marks, loans and pending dates. It runs only in that browser, makes no calls to your server and cannot read or change real data, so it is safe to show anyone. A banner at the top lets you switch between Owner, Auditor and Salesman, reset the sample data or exit.

## Adding a new shop (Owner → Shops → ➕ Add a new shop)
1. Type the shop name. Optionally pick **Copy the brand list from** an existing shop (names, sizes and MRP are copied).
2. Optionally add the first salesman with his PIN and the starting-stock date.
3. After you tap **Add shop**, a checklist shows what is left (brands, starting stock, salesman PIN) with a button for each, plus a ready-made message with the app link and steps. Send it on WhatsApp or copy it. The message never contains the PIN: give the PIN personally.
The new shop gets its own **"<Shop name> Sales"** tile on the first screen automatically.

## Admin, customers and Shop login
**Admin** is you, the person who sells the app. **Owner, Auditor and Salesman** belong to your customers. One customer can have many shops.

1. Put `ADMIN_PIN=<6 to 8 digits>` in `.deploy.env` and run `./deploy.sh` (it must differ from the owner and auditor PINs).
2. Open the app, tap **🛡️ Admin login**, enter the Admin PIN.
3. **Add a customer**: name, customer code (for example `kumar`), the customer's owner PIN, optional auditor PIN. Press **📨 Invite** to get a WhatsApp message with a link (`...?c=kumar`).
4. The customer taps **🏬 Shop login**, types the code (or just opens your link), and sees their own first page: Owner, Auditor and a Sales tile for each of their shops. Everything works as before. The owner adds shops (Shops tab), brands, salesmen and PINs.
5. Customers cannot see each other, and the Admin cannot see anybody's sales. The Admin can reset a customer's owner or auditor PIN, and switch a customer off (data is kept).
- The **🎬 Demo** tab on the first screen shows the app with sample data, nothing real is saved.
- The business you already had keeps working: leave the code empty at Shop login.
- Upgrade: run `./deploy.sh` again. Existing data is kept.

## Bank status for the Owner
- The Owner (like the Auditor) can mark UPI and cash as **Received to Bank**, mark a shortfall as received, and undo a mark. Every change is recorded in Activity.
- **🧮 Check cash deposit** (top of Bank status): choose one shop or all shops, optionally a date range, and the app adds up the cash that should be in the bank (cash counted minus what is already marked deposited). Type the cash you found deposited and it shows **Shortfall – not deposited**, or Matches, or Excess.
- **Mark days as deposited (oldest first)** applies that amount to the oldest days across the shops, so each day turns green or shows its own shortfall.

## Collection: expenses and loans received
- **Sale collected** = UPI + Cash + Expenses − loans received (expenses are paid out of the day's cash, so they count towards the sale).
- **Loans received in cash** are added to the day's cash automatically (Cash counted + Loans received in cash = Total cash). Do not count that money in the notes. This total is what Bank status and the deposit check expect to be deposited.
- Loans received by UPI: include them in the UPI amount.

## Auditor: sales summary (read-only)
The Auditor now has four tabs: 🏦 Bank credits, 📝 Closing stock, 📊 Sales summary and 📅 Day detail. Sales summary works for a day, month or date range: total sale, bottles, UPI, cash, loans given, expenses and the check, per shop and for all shops together, plus day-by-day and brand-wise totals. Everything is view-only. He still cannot see customer names, salesmen, PINs, invoices or the activity log, and can change only closing stock and bank marks.

## Upgrading keeps all your data and past calculations
An upgrade only replaces the program; the database is untouched. The rule "loans received in cash are added to the cash" applies from 9 Oct 2026. Earlier days are calculated exactly as before.

## Expenses and cash deposited for the selected date
On Home, Summary (day or range) and the Auditor's Sales summary, a card **💸 Expenses & 🏦 Cash deposited** follows the date, month or range you pick. It lists each expense (date, shop, note, amount) with the total, and shows Cash collected, **Amount deposited by cash** and Cash not deposited.

## Stock transfer between shops
In Entry (Owner) or Stock Entry (Salesman) there is a **🔁 Stock transfer to another shop** card: choose the other shop, the brand, the number of bottles and an optional note.
- The sending shop gets the stock as **sent** (taken off its stock, not counted as a sale). The other shop gets the same bottles as **received** on the same day. If the other shop did not stock that brand, it is added there (same MRP) for the owner to check.
- Sale = Opening + Received + transfers in − transfers out − Closing, so transfers never show up as sales. The Day detail and the CSV export list them.
- A salesman can send only from his own shop. **Undo** returns the stock to both shops.
- If a shop had already entered the closing stock of that brand for the day, update the closing count after the transfer (the app tells you).

## Shop login shows the customers and their shops
The Shop login screen lists every customer added in the Admin portal with the names of its shops. Tapping one opens its page (Owner, Auditor and a Sales tile per shop). The customer code box stays below for anyone not listed. In the Admin portal, **Hide from login list** removes a customer from this list (the code still works), and **Switch off** blocks the customer completely. If there is only one business, Shop login opens it directly.

## Adopt brands from another shop (Owner only)
Owner → **Brands** tab → **📥 Adopt brands from another shop**. Pick the source shop, tick the brands you want (or *Select all*), set the date and this shop's **opening stock** for each, then tap *Adopt selected brands*. Brands already in the shop (same name + size) are not listed. Adopted brands are normal brands afterwards, so the owner can edit their opening stock any time. Salesmen and the auditor never see this card. No new deployment settings: unzip over the project and run `./deploy.sh`.

## PINs are managed in the Admin portal (OWNER_PIN / AUDITOR_PIN now optional)
`.deploy.env` now needs only **`ADMIN_PIN`** (6 to 8 digits). Every Owner and Auditor PIN, including your **original business**, is set in the Admin portal: the first row, tagged *original business*, has **Owner PIN** and **Auditor PIN** buttons, plus *Hide/Show in login list*. A PIN saved there always wins over `OWNER_PIN` / `AUDITOR_PIN` in the env file, and each new customer gets its own PINs the same way.

Safe order for an existing deployment:
1. Deploy this version **keeping** your current `.deploy.env` (so nobody is locked out).
2. Sign in as Admin and set the Owner and Auditor PIN of the original business (you can re-enter the same numbers).
3. Optional: delete `OWNER_PIN` / `AUDITOR_PIN` from `.deploy.env` and run `./deploy.sh` again. Everyone must sign in once more after that. If you ever forget a PIN, the Admin can reset it.

## Telugu / English and Light / Dark / Auto theme
Every screen has two small buttons at the bottom-right: **తెలుగు / English** and a theme button (🌓 Auto, ☀️ Light, 🌙 Dark). Each phone remembers its own choice, so a salesman can use Telugu while the owner uses English. Names, numbers and anything not translated stay as typed. All Telugu wording is in `web/te.js` (English phrase on the left, Telugu on the right): to change a word, edit that file and run `./deploy.sh`. Please have someone who knows your shop's usual words check the Telugu once.

**Where is stock transfer?** Entry tab (Owner, or the Salesman of a shop when the customer has 2 or more shops). Tap **🔁 Transfer stock to another shop** at the top of the page to jump to the transfer box at the bottom.

**Transfer breakup:** on each brand card in Entry, a transfer shows as "➕ 48 received · from: *shop name*" (and "➖ … sent · to: *shop name*") with the note, and below it **Stock available (opening + transfers)**, for example opening 10 + 48 from another shop = 58. The sale is worked out from that total.

## Admin: shop names and PINs
In the Admin portal each customer (and the original business) shows its shops with ✏️ to **rename** a shop and **➕ Add shop** to add one. The same row has **Set / Change Owner PIN** and **Set / Change Auditor PIN** and shows whether each PIN is set. The owner of a customer can still rename shops and set salesman PINs inside the app.
Refreshing the page now keeps you signed in on the same tab and shop (an earlier version could show an empty screen after a refresh).

## Automatic saving (Entry page)
On the Entry / Stock Entry page, received and closing stock save by themselves about 1.5 seconds after you stop typing, when you change the date or tab, or when you leave the page. A line under the date shows **✓ Saved automatically hh:mm**. It needs the "who worked" name to be chosen first, and a brand whose closing is higher than its available stock is skipped with a warning. The **Save day / Submit stock entry** button is still there and is the only thing that saves the **collection** (cash, UPI, expenses, loans); the Brands page (prices, opening stock) also stays manual on purpose, because those edits change past figures.

## Cash: count notes OR enter a total

On the Entry page, in the Collection card, tap **🔢 Count notes** (denominations, as before) or **✍️ Enter total** (type one cash figure). Switching to *Enter total* pre-fills the figure from the notes already counted. The total is what the collection, bank deposit and shortfall maths use; old days stay as they were (counted notes). No new settings: unzip over the project and run `./deploy.sh` again.

## Transfers tab

Stock transfer now has its own tab (**🔁 Transfers** for the owner, **🔁 Transfer** for the salesman). Pick the date, the shop, brand and bottles, and send. The Entry page keeps a button that jumps to it. The **owner** also gets a *Transfer overview* in the same tab: for any day / month / date range it shows transfers and bottles moved, shop-wise sent / received / net, who sent to whom, and every transfer with brand, note and who did it. No new settings: unzip over the project and run `./deploy.sh`.

## Salesman: total sale and tally

On the salesman's Stock Entry page, a **🧮 Total sale for the day** card (bottles and ₹) now updates live as closing stock is entered. The Collection card also shows the **Matches / Short / Excess** line against the cash and UPI counted. No new settings: unzip over the project and run `./deploy.sh`.

## Breakup at the end of the Entry page

Both the owner's and the salesman's Entry page now end with **📋 Breakup of the day**, just above the save/submit button: sold quantity and amount for each brand, grouped by category with category totals and a grand total. It updates live as closing stock is entered. No new settings: unzip over the project and run `./deploy.sh`.

## Salesman: add a new brand from the Entry page

If a new brand arrives that day, the salesman taps **➕ New brand came today? Add it here** on the Stock Entry page, types the name, size and category and adds it. The brand appears for that date with **opening stock 0**; the salesman only enters the **Received** (and closing) stock. MRP stays 0 and the brand is flagged for the owner, who sets the MRP in the Brands tab. No new settings: unzip over the project and run `./deploy.sh`.

## Salesman enters the MRP of a new brand

When a salesman adds a new brand (from the Entry page or the Brands tab) he now enters its **MRP** too, so sales amounts are correct straight away. Opening stock is still forced to 0, and the brand stays flagged for the owner to check; only the owner can change an MRP afterwards. This needs the backend update, so run `./deploy.sh` after unzipping.
