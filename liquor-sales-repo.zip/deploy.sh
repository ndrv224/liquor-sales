#!/usr/bin/env bash
# One-command deploy. Usage: ./deploy.sh owner@example.com [budget-alert@example.com]
set -euo pipefail
OWNER_EMAIL="${1:?Usage: ./deploy.sh owner@example.com [alert@example.com]}"
ALERT_EMAIL="${2:-}"
STACK="${STACK:-liquor-tracker}"
REGION="${AWS_REGION:-ap-south-1}"   # Mumbai; change if you prefer another region

cd "$(dirname "$0")"
[ -f .deploy.env ] && . ./.deploy.env   # optional file with OWNER_PIN=..., so you never forget it
OWNER_PIN="${OWNER_PIN:-}"   # optional now: set the Owner/Auditor PINs of the original business in the Admin portal instead
for tool in aws sam; do command -v "$tool" >/dev/null || { echo "Missing '$tool'. See DEPLOY-GUIDE.md section 3."; exit 1; }; done
ACCOUNT=$(aws sts get-caller-identity --query Account --output text 2>/dev/null) || { echo "AWS is not configured. Run 'aws configure' (or use CloudShell)."; exit 1; }
echo "AWS account: $ACCOUNT   Region: $REGION   Stack: $STACK"
# PINs are the only key to the app, so they must be private numbers. OWNER_PIN is optional when an ADMIN_PIN is given:
# the Admin then sets every owner and auditor PIN (including the original business) inside the Admin portal.
if [ -n "$OWNER_PIN" ] && { [ "$OWNER_PIN" = "98765" ] || ! echo "$OWNER_PIN" | grep -Eq '^[0-9]{6,8}$'; }; then
  echo "STOP: the owner PIN must be 6 to 8 digits and not the default 98765 (or leave OWNER_PIN out and set it in the Admin portal)."
  exit 1
fi
if [ -z "$OWNER_PIN" ] && [ -z "${ADMIN_PIN:-}" ]; then
  echo "STOP: put at least ADMIN_PIN=12345678 (your own 6 to 8 digit number) in .deploy.env. You then set every Owner and Auditor PIN inside the Admin portal."
  exit 1
fi
if [ -z "$OWNER_PIN" ]; then echo "NOTE: no OWNER_PIN given. If the original business has no Owner PIN saved in the app yet, sign in as Admin and set it under the 'main' business."; fi
AUDITOR_PIN="${AUDITOR_PIN:-}"   # optional: the owner can set or change the auditor PIN later inside the app
if [ -n "$AUDITOR_PIN" ] && { ! echo "$AUDITOR_PIN" | grep -Eq '^[0-9]{6,8}$' || [ "$AUDITOR_PIN" = "$OWNER_PIN" ] || [ "$AUDITOR_PIN" = "98765" ]; }; then
  echo "STOP: AUDITOR_PIN must be 6 to 8 digits and different from the owner PIN (or leave it out and set it in the app)."
  exit 1
fi
PIN_RESET=""; [ "${RESET_PINS:-}" = "1" ] && PIN_RESET="r$(date +%s)"   # RESET_PINS=1 in .deploy.env clears PINs changed inside the app
# The free tier covers 25 read + 25 write capacity units in total across all DynamoDB tables in a region.
USED=$(aws dynamodb list-tables --region "$REGION" --query 'length(TableNames)' --output text 2>/dev/null || echo 0)
[ "${USED:-0}" -gt 0 ] && echo "NOTE: this account already has $USED DynamoDB table(s) in $REGION. This app uses 15 read + 10 write units; keep your total at or below 25 each to stay free."
# A first deploy that failed leaves the stack in ROLLBACK_COMPLETE, which cannot be updated: remove it and start clean.
ST=$(aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" --query 'Stacks[0].StackStatus' --output text 2>/dev/null || echo NONE)
if [ "$ST" = "ROLLBACK_COMPLETE" ]; then echo "Removing the earlier failed attempt..."; aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"; aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"; fi
sam build
# SAM rejects "Name=" with an empty value, so optional settings are only passed when they have a value
PARAMS=("OwnerEmail=$OWNER_EMAIL" "BusinessName=${BUSINESS_NAME:-My Business}" "SalesmanBackDays=${SALESMAN_BACK_DAYS:--1}" "TimeZone=${APP_TZ:-Asia/Kolkata}")
[ -n "$ALERT_EMAIL" ] && PARAMS+=("AlertEmail=$ALERT_EMAIL")
[ -n "$OWNER_PIN" ] && PARAMS+=("OwnerPin=$OWNER_PIN")
[ -n "$AUDITOR_PIN" ] && PARAMS+=("AuditorPin=$AUDITOR_PIN")
ADMIN_PIN="${ADMIN_PIN:-}"   # optional: PIN of the Admin who onboards customers
if [ -n "$ADMIN_PIN" ] && { ! echo "$ADMIN_PIN" | grep -Eq '^[0-9]{6,8}$' || [ "$ADMIN_PIN" = "$OWNER_PIN" ] || [ "$ADMIN_PIN" = "$AUDITOR_PIN" ]; }; then
  echo "STOP: ADMIN_PIN must be 6 to 8 digits and different from the owner and auditor PINs."; exit 1
fi
[ -n "$ADMIN_PIN" ] && PARAMS+=("AdminPin=$ADMIN_PIN")
[ -n "$PIN_RESET" ] && PARAMS+=("PinReset=$PIN_RESET")
sam deploy --stack-name "$STACK" --region "$REGION" --resolve-s3 \
  --capabilities CAPABILITY_IAM --no-confirm-changeset --no-fail-on-empty-changeset \
  --parameter-overrides "${PARAMS[@]}"

out() { aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
BUCKET=$(out BucketName); DIST=$(out DistributionId); SITE=$(out SiteUrl); BKT=$(out BackupBucketName)

cat > web/config.js <<CFG
window.APP_CONFIG = { business: "${BUSINESS_NAME:-My Business}", region: "$REGION", userPoolId: "$(out UserPoolId)", clientId: "$(out ClientId)", api: "/api" };
CFG

aws s3 sync web/ "s3://$BUCKET" --delete --region "$REGION" --cache-control "no-cache"
aws cloudfront create-invalidation --distribution-id "$DIST" --paths "/*" >/dev/null

echo
echo "Deployed: $SITE"
echo "Check $OWNER_EMAIL for the temporary password, then sign in."
echo "Nightly backups go to s3://$BKT/backups/ (see BACKUP.md)."
