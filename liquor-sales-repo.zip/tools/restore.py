#!/usr/bin/env python3
"""Restore a Liquor Sales Tracker backup into a DynamoDB table.

Works with both kinds of backup file: the nightly backups in S3 (*.json.gz) and the
"Download backup" file from the app (*.json).

  python3 tools/restore.py backup.json.gz --dry-run                 # just read and summarise it
  python3 tools/restore.py backup.json.gz --table <TableName>       # write it into the table

Find <TableName> in CloudFormation > your stack > Resources > Table.
Restoring overwrites items with the same keys; it never deletes anything. Run it in AWS CloudShell
(boto3 is already installed there) or after `pip install boto3` with `aws configure` done.
"""
import argparse, gzip, json, sys, time
from collections import Counter
from decimal import Decimal


def load(path):
    opener = gzip.open if path.endswith(".gz") else open
    with opener(path, "rt", encoding="utf-8") as f:
        doc = json.load(f, parse_float=Decimal, parse_int=Decimal)
    items = doc["items"] if isinstance(doc, dict) else doc
    if not isinstance(items, list) or not all("pk" in i and "sk" in i for i in items):
        sys.exit("This does not look like a Liquor Sales Tracker backup.")
    return doc, items


def summarise(items):
    kinds = Counter(str(i["pk"]).split("#")[0] for i in items)
    names = {"SHOPS": "shops", "BRANDS": "brands", "DAILY": "daily stock records", "CASH": "collection records", "LEDGER": "loans and expenses"}
    for k, n in sorted(kinds.items()):
        print(f"  {n:>6}  {names.get(k, k)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--table")
    ap.add_argument("--region", default="ap-south-1")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--yes", action="store_true", help="do not ask for confirmation")
    a = ap.parse_args()

    doc, items = load(a.file)
    print(f"Backup created: {doc.get('createdAt', 'unknown') if isinstance(doc, dict) else 'unknown'}   Records: {len(items)}")
    summarise(items)
    if a.dry_run or not a.table:
        print("\nDry run only. Add --table <TableName> to restore."); return
    if not a.yes and input(f"\nWrite {len(items)} records into table '{a.table}' ({a.region})? Type yes: ").strip() != "yes":
        sys.exit("Cancelled.")

    import boto3  # imported late so --dry-run works without it
    table = boto3.resource("dynamodb", region_name=a.region).Table(a.table)
    done, t0 = 0, time.time()
    # the table has small provisioned capacity (free tier), so write gently; batch_writer retries throttled writes itself
    with table.batch_writer() as w:
        for it in items:
            w.put_item(Item=it)
            done += 1
            if done % 25 == 0:
                time.sleep(2.5)  # about 10 writes per second
            if done % 250 == 0:
                print(f"  restored {done}/{len(items)}")
    print(f"Done: {done} records restored in {int(time.time() - t0)}s. Refresh the app.")


if __name__ == "__main__":
    main()
