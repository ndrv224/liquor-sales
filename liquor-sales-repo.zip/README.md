# Liquor Sales Tracker: AWS deployment (free-tier friendly)

**New to AWS? Follow `DEPLOY-GUIDE.md` step by step.** This file is the technical reference.

## What gets created
| Piece | AWS service | Free-tier position |
|---|---|---|
| Website | S3 (private) + CloudFront | CloudFront always-free: 1 TB out and 10 M requests per month. S3 holds about 100 KB (a fraction of a cent) |
| API | Lambda (arm64) + Function URL | Always-free: 1 M requests and 400,000 GB-seconds per month. No API Gateway is used |
| Database | DynamoDB, **provisioned** 15 RCU / 10 WCU | Always-free: 25 GB, 25 RCU, 25 WCU |
| Login and roles | Cognito (Lite tier), groups `owner` and `salesman` | Free for the first 10,000 monthly users |
| Safety net | AWS Budgets email alert (optional) | First 2 budgets are free |
| Logs | CloudWatch, 7-day retention | Small |

Deliberately NOT used (they cost money even when idle): NAT Gateway, RDS/Aurora, EC2, Route 53, WAF, API Gateway, Secrets Manager, DynamoDB on-demand.

**Your account type matters.** For accounts created after 15 July 2025 you choose a Free plan (credits, up to 6 months) or a Paid plan. The always-free allowances above apply on both. Always-free usage never uses up your credits, and this app is designed to stay inside it. Check your plan in the Billing console.

## Prerequisites
1. An AWS account and the AWS CLI configured (`aws configure`).
2. AWS SAM CLI (https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html).
3. Node.js 20 or newer (only for the optional tests).

## Deploy (about 10 minutes)
```bash
cd liquor-tracker-aws
./deploy.sh owner@yourmail.com budget-alerts@yourmail.com   # 2nd email is optional
OWNER_PIN=246810 ./deploy.sh owner@yourmail.com             # choose your own owner PIN (default 98765)
```
The script builds, deploys the stack (default region `ap-south-1`, Mumbai; set `AWS_REGION` to change), writes `web/config.js`, uploads the site and clears the CDN cache. It prints the site URL.

1. Cognito emails a temporary password to the owner address.
2. Open the URL, sign in, and choose a new password.
3. Open the **Shops** tab: invite salesmen with **Invite a user** (role *salesman*). They get an email with a temporary password.
4. Add shops and brands and set MRP and opening stock (Brands tab, **Edit**).

Update later: change the code, then run `./deploy.sh` again (same arguments).

## Owner PIN
Owner accounts must enter a PIN after signing in (default `98765`, set with `OWNER_PIN`; change it at your first deploy). The server checks the PIN on every owner request, so it cannot be skipped from the browser. After 5 wrong tries the owner is locked out for 15 minutes. The page also locks itself after 10 idle minutes, and the **🔒 Lock** button locks it at once. Salesmen never need the PIN.
A 5-digit PIN is a second lock only. The real protection is the owner's Cognito password, so use a strong one. To change the PIN later: `OWNER_PIN=newpin ./deploy.sh ...`.

## Expenses, loans and the daily check
* On the entry screen, add **expenses** (paid from the day's cash) and **loans** (credit given to a customer) with a note or customer name.
* The owner's check is: `Sale = UPI + Cash + Loan given + Expenses`. Any gap shows as Short or Excess.
* In the **💳 Ledger** tab the owner marks an open loan as received by **Cash** or **UPI**. It then shows under that day's "old loans recovered", and **Undo** reverses it.

## Bank reconciliation
The salesman enters the day's UPI and cash. The next morning the owner opens the **🏦 Bank** tab and taps **Mark received** for that day's UPI (and the cash deposit). The app proposes the collected amount; type a different amount if the bank credited less (for example after UPI charges). **Undo** reverses a mark. The tab is **shop-wise**: pick one shop or **All shops**, and each shop gets its own table. Pending items show **⏳ Pending**; once marked, the cell turns **green** and says **✅ Received to Bank** with the amount and date (also on the Day Summary and the Shops tab). Once a day is marked, the salesman can no longer edit that day's collection. The Home screen shows what is still awaiting the bank.

The salesman also has a **💳 Loans** tab (with the number of open loans on the tab): the shop's outstanding loans with how many days old each is, and loans received in the last 30 days. He can mark a payment there too.

## Loans received at the counter
On the entry screen the salesman sees every open loan with **💵 Received cash** and **📱 Received UPI** buttons. Marking one adds it to that day's collection, apart from sale: the day's check becomes (Sale + Loans received) = (UPI + Cash + Loan given + Expenses), so the salesman includes the money in the UPI and cash he counts. The loan shows green as **✅ Loan received** in the list, on the Day Summary and in the owner's Ledger tab ("at counter"). Only the owner can undo it. If a customer pays an old loan that was never recorded here, the salesman uses **Add a loan payment received** (name, amount, cash or UPI); it counts as a payment received, not as a new loan given. A loan the owner marks from the Ledger tab is "direct to owner" and is not added to the till.

## Backups
Nightly automatic backup to a private S3 bucket (kept 90 days), a **Back up now** button, downloads of the full backup and Excel-ready CSV reports, and `tools/restore.py` for restoring. Everything is explained in `BACKUP.md`.

## Cash shortfall
If the owner marks less cash deposited than the salesman counted (for example ₹1,500 of ₹2,000), the ₹500 difference stays on the **salesman's cash balance**. The salesman sees a red alert with the amount and the days involved, a notice when he opens the app, and the balance carried into the next day's cash to hand over. The owner sees it on Home and in the Bank tab (**Cash shortfalls** view). When the salesman hands the cash over, the owner taps **Shortfall received** and the balance clears.

## Reporting periods (owner)
Home, Summary, Ledger, Bank (**Selected period**) and Shops share one period bar: **Day**, **Month** or **Date range**, with ‹ › arrows and quick buttons (Today, Yesterday, This week, This month, Last month, Last 7 days, Last 30 days). The choice stays when you move between tabs.
* **Home** totals sale, bottles, UPI, cash, loans and expenses for the period, with a trend chart, a shop-wise table (All shops or one shop), top brands, and the sale-vs-collection check.
* **Summary**: a single day shows the per-brand table; a longer period shows day-by-day totals and brand-wise totals for the selected shop.
* Periods that reach back before the loaded data (default 180 days) fetch older entries automatically, up to about 2 years.
* Salesmen keep a simple single-day picker on their Day Summary.

## How far back a salesman can enter
For now a salesman can enter or correct **any past date** (never a future date). When he changes an old closing stock, every later day recalculates automatically, because each day's opening is the previous day's closing, so sale, amount and stock up to today all follow. To lock older days later, set `SALESMAN_BACK_DAYS=2` in `.deploy.env` (2 = today + previous 2 days; -1 = no limit) and run `./deploy.sh` again; the server enforces it even if someone bypasses the screen. "Today" follows `APP_TZ` (default Asia/Kolkata).

## Signing in
The first screen asks **Owner** or **Salesman**. Each opens its own sign-in. If the account does not match the choice (for example a salesman account on the Owner button) the app says so and returns to the first screen. Owners then enter the PIN. **⇄ Role** in the header goes back to the first screen.

## Who can do what (enforced on the server, in `backend/index.mjs`)
| Action | Owner | Salesman |
|---|---|---|
| Add or edit shops, MRP, opening stock, serial numbers; delete brands; invite users | Yes | No |
| Enter received and closing stock; enter UPI, cash denominations, expenses and loans | Yes | Yes |
| Mark a loan received by cash or UPI at the counter | Yes | Yes |
| Undo a loan payment; mark UPI/cash received in bank; delete ledger entries; unlock owner pages (PIN) | Yes | No |
| Add a new brand | Yes | Yes. MRP and opening stock are forced to 0 and the brand is flagged for the owner |
| See the Day Summary (sales, UPI, cash, loans, expenses, difference, bank status) | Yes | Yes (read-only) |
| See the Home dashboard, Ledger, Bank and Shops tabs, all-shops totals | Yes | No |

A salesman's saved entries always use the brand's saved MRP, whatever the browser sends. Tests: `node --test test/backend.test.mjs`.

## Free-tier sizing and limits
* Each page load reads about 180 days of entries. With 40 brands per shop this is a few hundred KB, which fits easily in the 15 RCU table. The app refreshes every 60 seconds only when a tab is open, idle and visible.
* Roughly 10 users making a few hundred requests a day is far below 1 M Lambda requests per month.
* If you grow past about 10 shops with 100+ brands, raise `ReadCapacityUnits` (still free up to 25 in total) or load fewer days (`days=` in `loadAll`).
* A salesman can switch between shops. Locking a user to one shop needs a `custom:shop` attribute in Cognito and a server check. This is not built yet.

## Keeping the bill at zero
**Honest note:** this is designed to cost nothing, but AWS cannot guarantee it. Cost can only appear if you exceed an always-free limit or add other services.
* **Alerts.** Give `deploy.sh` an alert email. You get an email at about **$0.01** of spend, at 80% of $1, and if a month is forecast to pass $1. Also turn on Billing, Billing preferences, **Free Tier usage alerts**.
* **DynamoDB limit is shared.** The free allowance is 25 read and 25 write units in total across all tables in a region. This app uses 15 and 10. If the account already has other provisioned tables, keep the total at or below 25 each. `deploy.sh` warns you if other tables exist.
* **Public API address.** The Lambda address is reachable by anyone but every call needs a valid sign-in token. Someone hammering it could use up the free 1 million monthly requests; beyond that Lambda costs about $0.20 per million. The budget alert will tell you.
* **Free plan ends.** New accounts on the Free plan close after 6 months or when credits run out. Switch to the Paid plan to keep running; the always-free services stay free.
* Do not add NAT gateways, RDS, EC2, load balancers, Route 53, WAF or Secrets Manager.
* **Check usage monthly:** Billing, Free Tier page.
* **Stop everything:** `./destroy.sh` (add `--delete-data` to remove the database and users too).

## Backup
DynamoDB point-in-time recovery costs extra and is off. Use a free manual export when needed:
`aws dynamodb scan --table-name <table> > backup.json` (the table name is in the CloudFormation console).

## Remove everything
```bash
aws s3 rm s3://<BucketName> --recursive
aws cloudformation delete-stack --stack-name liquor-tracker
```
Then delete the retained DynamoDB table and Cognito user pool by hand if you no longer need the data.

## Troubleshooting
* **403 or 'Forbidden' from /api**: Function URLs created after October 2025 need both permissions, which the template includes. If you edited the template, check `ApiUrlPermission` and `ApiInvokePermission`.
* **'No role assigned'**: the user is not in the `owner` or `salesman` group (Cognito, Users, Groups).
* **Blank login screen**: `web/config.js` is empty; run `./deploy.sh`.
* **Old screen after a deploy**: hard refresh. The script already clears the CDN cache.


## Stock invoice papers

Salesmen open the **🧾 Invoices** tab, tap **📷 Take photo** (or **📎 Choose file** for a PDF), fill the supplier, invoice number and amount (optional), and upload. Owners see every shop's invoices in their own **🧾 Invoices** tab (filtered by the Day / Month / Range selector), can open or download each one, and can delete.

- Photos (JPG/PNG/WEBP) are shrunk on the phone before upload; PDFs are sent as they are. Limit is 3.5 MB per file, 30 per shop per day.
- Files sit in a private S3 bucket (`InvoiceBucket`) and are only reachable through the app, after login. A salesman can open only his own uploads (last 7 days); only the owner can delete.
- Invoice dates follow the same salesman date rule as stock entry.
- Free-tier note: S3 gives 5 GB free for 12 months. At about 1 MB per invoice and 5 invoices a day that is roughly 3 years, so check the bucket size now and then.
- The nightly backup covers the data (details of each invoice), not the files. See BACKUP.md.

## Roles: Owner, Auditor, Salesman

| | Salesman | Auditor | Owner |
|---|---|---|---|
| Enter received / closing stock, UPI, cash, expenses, loans | yes | no | yes (also sets MRP, opening stock, shops, users) |
| Upload stock invoices | yes | no | yes |
| See sales, pending loans, cash not yet in bank, invoices purchased | own shop, one day | **all shops, any period** | **all shops, any period** (Home "At a glance") |
| **Confirm money received in the bank** (UPI / cash deposit, shortfall) | no | **yes, only the auditor** | no (view only: "Bank status") |
| Delete invoices, ledger entries, manage users, backups | no | no | yes |

The auditor signs in with their own email and password and then enters the same PIN as the owner (default 98765, checked on the server with the same 5-wrong-tries lockout, and auto-locks after 10 minutes idle) and sees Home, Bank, Summary, Ledger and Invoices. The owner invites the auditor from **Shops > Invite a user > Auditor**. This is enforced on the server, not only on the screen. If the owner also needs to mark the bank, make the owner's email an auditor account too, or tell me and I will add a switch.

## Activity log (who changed what)

Because salesmen can now correct any past date, the app keeps an edit history. Owner and Auditor open **🕵️ Activity** to see, for the last 30 days: every change to an existing closing or received figure (old → new value), every stock entry made for a past date (marked ⚠ back-dated), changes to a day's UPI / cash totals, bank confirmations by the auditor, and deleted ledger entries or invoices, each with who did it and when. Salesmen cannot see or edit the log. It is included in the nightly backup. Entries are tiny, so it stays well inside the free tier.

## Salesman name for the day

Every stock entry now asks **"Salesman who worked this day"** and will not save without it (the server refuses a salesman save with no name). The name is stored with that day's stock, shown on the Day Summary as "Worked by", added as a Salesman column in the day-by-day table, included in the sales-summary CSV, and shown in the Activity log next to any change. The field is pre-filled with the last name used on that device, so on a shared phone check it is the right person.

### Who can be picked as the salesman

The owner or the auditor keeps the list in the **👥 Salesmen** tab: add a new salesman when someone joins, mark him **not working here** when he leaves (past entries keep his name), or remove him. The list is **per shop**: switch the shop at the top, then add that shop's salesmen (the same person can be added to two shops). On the Stock Entry screen a salesman can only choose a name from the list of the shop he is entering for, so nobody can type a different or misspelt name. Until the first name is added the field accepts any text. Changes to the list appear in the Activity log. Note: these are names for the daily records, separate from the login accounts you invite under Shops.

## Starting stock date
Each shop has a starting-stock date set by the owner (Brands tab). Salesmen enter from the next day and see a list of pending dates. See DEPLOY-GUIDE.md.
