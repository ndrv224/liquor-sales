/* Language (English / Telugu) and theme (Auto / Light / Dark).
   The app is written in English. In Telugu mode every piece of visible text is looked up in TE_DICT (te.js) and replaced on screen;
   names, numbers and anything not in the dictionary stay exactly as typed. Switching back to English restores the original text. */
(function () {
  var D = window.TE_DICT || {}, W = window.TE_WORDS || {}, PAT = (window.TE_PAT || []).map(function (p) { return [new RegExp(p[0]), p[1]]; }), doc = document;
  var lang = "en", theme = "auto";
  try { lang = localStorage.getItem("liq_lang") === "te" ? "te" : "en"; theme = localStorage.getItem("liq_theme") || "auto"; } catch (e) {}
  if (theme !== "light" && theme !== "dark") theme = "auto";
  var orig = new WeakMap(), outv = new WeakMap(), aorig = new WeakMap();
  var NUM = /₹?\d[\d,]*(?:\.\d+)?%?/g;

  function lookup(s) {            // s has no surrounding spaces; returns Telugu or null
    if (!/[A-Za-z]/.test(s)) return null;
    if (D[s] != null) return D[s];
    var nums = [], key = s.replace(NUM, function (m) { nums.push(m); return "{n}"; });
    if (key !== s && D[key] != null) { var i = 0; return D[key].replace(/\{n\}/g, function () { return nums[i++] != null ? nums[i - 1] : ""; }); }
    var pm = s.match(/^([^A-Za-z0-9{(₹]+)(\S.*)$/);   // leading emoji / arrows / bullets are kept: "📅 Pending dates" -> "📅 " + translation
    if (pm) { var pt = lookup(pm[2]); if (pt != null) return pm[1] + pt; }
    for (var pi = 0; pi < PAT.length; pi++) {   // sentences with a name inside: "Add a salesman to X"
      var mm = key.match(PAT[pi][0]);
      if (mm) { var ni = 0; return key.replace(PAT[pi][0], PAT[pi][1]).replace(/\{n\}/g, function () { return nums[ni++] != null ? nums[ni - 1] : ""; }); }
    }
    if (s.indexOf(" · ") > 0) {   // "Kumar Main · 3 brands" : translate each part
      var parts = s.split(" · "), hit = false, res = parts.map(function (p) { var t = lookup(p); if (t != null) hit = true; return t != null ? t : p; });
      if (hit) return res.join(" · ");
    }
    if (!/\d/.test(s)) return null;   // weekday / month names are only swapped in dates
    var changed = false, w = s.replace(/[A-Za-z]+/g, function (m) { if (W[m] != null) { changed = true; return W[m]; } return m; });   // weekday and month names
    return changed ? w : null;
  }
  function tr(raw) {
    var lead = raw.match(/^\s*/)[0], trail = raw.match(/\s*$/)[0], core = raw.slice(lead.length, raw.length - trail.length);
    if (!core) return null;
    if (core.indexOf("\n") >= 0) {
      var any = false, lines = core.split("\n").map(function (l) { var t = lookup(l.replace(/\s+/g, " ").trim()); if (t != null) { any = true; return t; } return l; });
      return any ? lead + lines.join("\n") + trail : null;
    }
    var t = lookup(core.replace(/\s+/g, " "));
    return t == null ? null : lead + t + trail;
  }
  function doText(n) {
    var cur = n.nodeValue, o = orig.get(n);
    if (o === undefined || cur !== outv.get(n)) { o = cur; orig.set(n, o); }
    var want = o;
    if (lang === "te") { var t = tr(o); if (t != null) want = t; }
    outv.set(n, want);
    if (want !== cur) n.nodeValue = want;
  }
  var ATTRS = ["placeholder", "title", "aria-label"];
  function doAttrs(el) {
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i]; if (!el.hasAttribute(a)) continue;
      var m = aorig.get(el); if (!m) { m = {}; aorig.set(el, m); }
      var cur = el.getAttribute(a), rec = m[a];
      if (!rec || cur !== rec.out) rec = m[a] = { o: cur, out: cur };
      var want = rec.o; if (lang === "te") { var t = tr(rec.o); if (t != null) want = t; }
      rec.out = want; if (want !== cur) el.setAttribute(a, want);
    }
  }
  function skip(el) { return el.nodeType === 1 && /^(SCRIPT|STYLE|TEXTAREA|NOSCRIPT)$/.test(el.tagName) || (el.hasAttribute && el.hasAttribute("data-nt")); }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1 || skip(root)) return;
    doAttrs(root);
    for (var c = root.firstChild; c; c = c.nextSibling) walk(c);
  }
  var busy = false;
  var mo = new MutationObserver(function (list) {
    if (busy) return; busy = true;
    try {
      list.forEach(function (m) {
        if (m.type === "characterData") doText(m.target);
        else m.addedNodes.forEach(walk);
      });
    } finally { busy = false; }
  });
  function sweep() { busy = true; try { walk(doc.body); } finally { busy = false; } }

  function setTheme(t) {
    theme = t;
    var r = doc.documentElement;
    if (t === "light" || t === "dark") r.setAttribute("data-theme", t); else r.removeAttribute("data-theme");
    try { localStorage.setItem("liq_theme", t); } catch (e) {}
    paint();
  }
  function setLang(l) {
    lang = l; doc.documentElement.setAttribute("lang", l);
    try { localStorage.setItem("liq_lang", l); } catch (e) {}
    sweep(); paint();
  }
  var bar;
  function paint() {
    if (!bar) return;
    bar.querySelector(".lb").textContent = lang === "te" ? "English" : "తెలుగు";
    var ic = { auto: "🌓", light: "☀️", dark: "🌙" }, nm = { auto: "Theme: Auto (follows your phone)", light: "Theme: Light", dark: "Theme: Dark" };
    var tb = bar.querySelector(".tb"); tb.textContent = ic[theme]; tb.setAttribute("title", nm[theme]); tb.setAttribute("aria-label", nm[theme]);
    // the bar itself is never translated by the sweep (data-nt); the title is set in the chosen language here
    if (lang === "te") { var te = { auto: "రంగు: ఆటో (ఫోన్‌ను అనుసరిస్తుంది)", light: "రంగు: లైట్", dark: "రంగు: డార్క్" }; tb.setAttribute("title", te[theme]); tb.setAttribute("aria-label", te[theme]); }
  }
  function build() {
    var st = doc.createElement("style");
    st.textContent = "body{padding-bottom:64px!important}#ltbar{position:fixed;right:10px;bottom:10px;z-index:45;display:flex;gap:6px;align-items:center;opacity:.92}" +
      "#ltbar button{min-height:0;height:34px;padding:0 12px;border-radius:99px;font-size:13px;background:var(--card);color:var(--tx);border:1px solid var(--bd);box-shadow:0 2px 8px rgba(0,0,0,.18)}" +
      "#ltbar .tb{width:34px;padding:0;font-size:16px}" +
      "html[lang=te] body{font-family:system-ui,-apple-system,'Noto Sans Telugu','Nirmala UI','Gautami',Roboto,sans-serif;line-height:1.55}" +
      "html[lang=te] nav button{font-size:11px}" +
      ":root[data-theme=dark]{color-scheme:dark}:root[data-theme=light]{color-scheme:light}" +
      "@media(prefers-color-scheme:dark){:root:not([data-theme=light]){color-scheme:dark}}";
    doc.head.appendChild(st);
    bar = doc.createElement("div"); bar.id = "ltbar"; bar.setAttribute("data-nt", "");
    bar.innerHTML = '<button class="lb" type="button" title="Language"></button><button class="tb" type="button"></button>';
    bar.querySelector(".lb").onclick = function () { setLang(lang === "te" ? "en" : "te"); };
    bar.querySelector(".tb").onclick = function () { setTheme(theme === "auto" ? "light" : theme === "light" ? "dark" : "auto"); };
    doc.body.appendChild(bar); paint();
  }
  build();
  doc.documentElement.setAttribute("lang", lang);
  if (lang === "te") sweep();
  mo.observe(doc.body, { childList: true, subtree: true, characterData: true });
  window.LT = { setLang: setLang, setTheme: setTheme, tr: tr, lang: function () { return lang; } };
})();
